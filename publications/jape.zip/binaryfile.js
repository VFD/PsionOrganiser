var FileStatus = {
   "loading" : 0,
   "ready" : 1,
   "error" : 2
};

function BinaryFile(inputFile, isLocal, callback){
   var _name;
   var _data;
   var _isLocal = isLocal;
   var _status = FileStatus.loading;

   this.status = function(){ return _status; }
   this.isReady = function(){ return _status == FileStatus.ready; }
   this.getData = function(){ return _data; }
   this.getName = function(){ return _name; }

   function downloadFailed() {
      _status = FileStatus.error;
      alert("Failed to download binary file named "+_name);
   };
   function loadFailed() {
      _status = FileStatus.error;
      alert("Failed to open binary file named "+_name);
   };

   if( !isLocal ){
      _name = inputFile;
      if (!_name || _name.length == 0) downloadFailed();
      else{
         // Create a XMLHttpRequest and handle the onload and onerror events.
         var oReq = new XMLHttpRequest();
         oReq.open("GET", _name, true);
         oReq.responseType = "arraybuffer";
         oReq.onload = function (oEvent) {
            _data = new Uint8Array(oReq.response);
            _status = FileStatus.ready;
            if(callback) callback();
         };
         oReq.onerror = downloadFailed;
         // Read the binary file.
         oReq.send(null);
      }
   }else{
      if (inputFile.length != 0)
      {
         var file = inputFile[0];
         _name = file.fileName;
         // Create a FileReader and handle the onload and onerror events.
         var reader = new FileReader();
         reader.onload = function (e) {
            _data = new Uint8Array(e.target.result);
            _status = FileStatus.ready;
            if(callback) callback();
         };
         reader.onerror = loadFailed;
         // Read the binary file.
         reader.readAsArrayBuffer(inputFile[0]);
      } else {
         alert("Please select a binary file");
      }
   }
}