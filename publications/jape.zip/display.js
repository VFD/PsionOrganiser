'use strict';

var char2 =new Uint8Array(
   [0,0,0,0,0,0,0,0,4,4,4,4,0,0,4,0,10,10,10,0,0,0,0,0,10,10,31,10,31,10,10,0,4,15,20,14,5,30,4,0,24,25,2,4,8,19,3,0,12,18,20,8,21,18,13,0,12,4,8,0,0,0,0,0,
   2,4,8,8,8,4,2,0,8,4,2,2,2,4,8,0,0,4,21,14,21,4,0,0,0,4,4,31,4,4,0,0,0,0,0,0,12,4,8,0,0,0,0,31,0,0,0,0,0,0,0,0,0,12,12,0,0,1,2,4,8,16,0,0,
   14,17,19,21,25,17,14,0,4,12,4,4,4,4,14,0,14,17,1,2,4,8,31,0,31,2,4,2,1,17,14,0,2,6,10,18,31,2,2,0,31,16,30,1,1,17,14,0,6,8,16,30,17,17,14,0,31,1,2,4,8,8,8,0,
   14,17,17,14,17,17,14,0,14,17,17,15,1,2,12,0,0,12,12,0,12,12,0,0,0,12,12,0,12,4,8,0,2,4,8,16,8,4,2,0,0,0,31,0,31,0,0,0,8,4,2,1,2,4,8,0,14,17,1,2,4,0,4,0,
   14,17,1,13,21,21,14,0,14,17,17,17,31,17,17,0,30,17,17,30,17,17,30,0,14,17,16,16,16,17,14,0,28,18,17,17,17,18,28,0,31,16,16,30,16,16,31,0,31,16,16,30,16,16,16,0,14,17,16,23,17,17,15,0,
   17,17,17,31,17,17,17,0,14,4,4,4,4,4,14,0,7,2,2,2,2,18,12,0,17,18,20,24,20,18,17,0,16,16,16,16,16,16,31,0,17,27,21,21,17,17,17,0,17,17,25,21,19,17,17,0,14,17,17,17,17,17,14,0,
   30,17,17,30,16,16,16,0,14,17,17,17,21,18,13,0,30,17,17,30,20,18,17,0,15,16,16,14,1,1,30,0,31,4,4,4,4,4,4,0,17,17,17,17,17,17,14,0,17,17,17,17,17,10,4,0,17,17,17,21,21,21,10,0,
   17,17,10,4,10,17,17,0,17,17,17,10,4,4,4,0,31,1,2,4,8,16,31,0,14,8,8,8,8,8,14,0,17,10,31,4,31,4,4,0,14,2,2,2,2,2,14,0,4,10,17,0,0,0,0,0,0,0,0,0,0,0,31,0,
   8,4,2,0,0,0,0,0,0,0,14,1,15,17,15,0,16,16,22,25,17,17,30,0,0,0,14,16,16,17,14,0,1,1,13,19,17,17,15,0,0,0,14,17,31,16,14,0,6,9,8,28,8,8,8,0,0,15,17,17,15,1,14,0,
   16,16,22,25,17,17,17,0,4,0,12,4,4,4,14,0,2,0,6,2,2,18,12,0,16,16,18,20,24,20,18,0,12,4,4,4,4,4,14,0,0,0,26,21,21,17,17,0,0,0,22,25,17,17,17,0,0,0,14,17,17,17,14,0,
   0,0,30,17,30,16,16,0,0,0,13,19,15,1,1,0,0,0,22,25,16,16,16,0,0,0,14,16,14,1,30,0,8,8,28,8,8,9,6,0,0,0,17,17,17,19,13,0,0,0,17,17,17,10,4,0,0,0,17,17,21,21,10,0,
   0,0,17,10,4,10,17,0,0,0,17,17,15,1,14,0,0,0,31,2,4,8,31,0,2,4,4,8,4,4,2,0,4,4,4,4,4,4,4,0,8,4,4,2,4,4,8,0,0,4,2,31,2,4,0,0,0,4,8,31,8,4,0,0,
   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
   0,0,0,0,0,0,0,0,0,0,0,0,28,20,28,0,7,4,4,4,0,0,0,0,0,0,0,4,4,4,28,0,0,0,0,0,16,8,4,0,0,0,0,12,12,0,0,0,0,31,1,31,1,2,4,0,0,0,31,1,6,4,8,0,
   0,0,2,4,12,20,4,0,0,0,4,31,17,1,6,0,0,0,0,31,4,4,31,0,0,0,2,31,6,10,18,0,0,0,8,31,9,10,8,0,0,0,0,14,2,2,31,0,0,0,30,2,30,2,30,0,0,0,0,21,21,1,6,0,
   0,0,0,31,0,0,0,0,31,1,5,6,4,4,8,0,1,2,4,12,20,4,4,0,4,31,17,17,1,2,4,0,0,31,4,4,4,4,31,0,2,31,2,6,10,18,2,0,8,31,9,9,9,9,18,0,4,31,4,31,4,4,4,0,
   0,15,9,17,1,2,12,0,8,15,18,2,2,2,4,0,0,31,1,1,1,1,31,0,10,31,10,10,2,4,8,0,0,24,1,25,1,2,28,0,0,31,1,2,4,10,17,0,8,31,9,10,8,8,7,0,0,17,17,9,1,2,12,0,
   0,15,9,21,3,2,12,0,2,28,4,31,4,4,8,0,0,21,21,21,1,2,4,0,14,0,31,4,4,4,8,0,8,8,8,12,10,8,8,0,4,4,31,4,4,8,16,0,0,14,0,0,0,0,31,0,0,31,1,10,4,10,16,0,
   4,31,2,4,14,21,4,0,2,2,2,2,2,4,8,0,0,4,2,17,17,17,17,0,16,16,31,16,16,16,15,0,0,31,1,1,1,2,12,0,0,8,20,2,1,1,0,0,4,31,4,4,21,21,4,0,0,31,1,1,10,4,2,0,
   0,14,0,14,0,14,1,0,0,4,8,16,17,31,1,0,0,1,1,10,4,10,16,0,0,31,8,31,8,8,7,0,8,8,31,9,10,8,8,0,0,14,2,2,2,2,31,0,0,31,1,31,1,1,31,0,14,0,31,1,1,2,4,0,
   18,18,18,18,2,4,8,0,0,4,20,20,21,21,22,0,0,16,16,17,18,20,24,0,0,31,17,17,17,17,31,0,0,31,17,17,1,2,4,0,0,24,0,1,1,2,28,0,4,18,8,0,0,0,0,0,28,20,28,0,0,0,0,0,
   0,0,9,21,18,18,13,0,10,0,14,1,15,17,15,0,0,0,14,17,30,17,30,16,0,0,14,16,12,17,14,0,0,0,17,17,17,19,29,16,0,0,15,20,18,17,14,0,0,0,6,9,17,17,30,16,0,0,15,17,17,17,15,1,
   0,0,7,4,4,20,8,0,0,2,26,2,0,0,0,0,2,0,6,2,2,2,2,2,0,20,8,20,0,0,0,0,0,4,14,20,21,14,4,0,8,8,28,8,28,8,15,0,14,0,22,25,17,17,17,0,10,0,14,17,17,17,14,0,
   0,0,22,25,17,17,30,16,0,0,13,19,17,17,15,1,0,14,17,31,17,17,14,0,0,0,0,11,21,26,0,0,0,0,14,17,17,10,27,0,10,0,17,17,17,19,13,0,31,16,8,4,8,16,31,0,0,0,31,10,10,10,19,0,
   31,0,17,10,4,10,17,0,0,0,17,17,17,17,15,1,0,1,30,4,31,4,4,0,0,0,31,8,15,9,17,0,0,0,31,21,31,17,17,0,0,0,4,0,31,0,4,0,0,0,0,0,0,0,0,0,31,31,31,31,31,31,31,31]);

var char4 = new Uint8Array(
   [0,0,0,0,0,0,0,0,4,4,4,4,0,0,4,0,10,10,10,0,0,0,0,0,10,10,31,10,31,10,10,0,4,15,20,14,5,30,4,0,24,25,2,4,8,19,3,0,12,18,20,8,21,18,13,0,12,4,8,0,0,0,0,0,
   2,4,8,8,8,4,2,0,8,4,2,2,2,4,8,0,0,4,21,14,21,4,0,0,0,4,4,31,4,4,0,0,0,0,0,0,12,4,8,0,0,0,0,31,0,0,0,0,0,0,0,0,0,12,12,0,0,1,2,4,8,16,0,0,
   14,17,19,21,25,17,14,0,4,12,4,4,4,4,14,0,14,17,1,2,4,8,31,0,31,2,4,2,1,17,14,0,2,6,10,18,31,2,2,0,31,16,30,1,1,17,14,0,6,8,16,30,17,17,14,0,31,1,2,4,8,8,8,0,
   14,17,17,14,17,17,14,0,14,17,17,15,1,2,12,0,0,12,12,0,12,12,0,0,0,12,12,0,12,4,8,0,2,4,8,16,8,4,2,0,0,0,31,0,31,0,0,0,8,4,2,1,2,4,8,0,14,17,1,2,4,0,4,0,
   14,17,1,13,21,21,14,0,14,17,17,17,31,17,17,0,30,17,17,30,17,17,30,0,14,17,16,16,16,17,14,0,28,18,17,17,17,18,28,0,31,16,16,30,16,16,31,0,31,16,16,30,16,16,16,0,14,17,16,23,17,17,15,0,
   17,17,17,31,17,17,17,0,14,4,4,4,4,4,14,0,7,2,2,2,2,18,12,0,17,18,20,24,20,18,17,0,16,16,16,16,16,16,31,0,17,27,21,21,17,17,17,0,17,17,25,21,19,17,17,0,14,17,17,17,17,17,14,0,
   30,17,17,30,16,16,16,0,14,17,17,17,21,18,13,0,30,17,17,30,20,18,17,0,15,16,16,14,1,1,30,0,31,4,4,4,4,4,4,0,17,17,17,17,17,17,14,0,17,17,17,17,17,10,4,0,17,17,17,21,21,21,10,0,
   17,17,10,4,10,17,17,0,17,17,17,10,4,4,4,0,31,1,2,4,8,16,31,0,14,8,8,8,8,8,14,0,0,16,8,4,2,1,0,0,14,2,2,2,2,2,14,0,4,10,17,0,0,0,0,0,0,0,0,0,0,0,31,0,
   8,4,2,0,0,0,0,0,0,0,14,1,15,17,15,0,16,16,22,25,17,17,30,0,0,0,14,16,16,17,14,0,1,1,13,19,17,17,15,0,0,0,14,17,31,16,14,0,6,9,8,28,8,8,8,0,0,15,17,17,15,1,14,0,
   16,16,22,25,17,17,17,0,4,0,12,4,4,4,14,0,2,0,6,2,2,18,12,0,16,16,18,20,24,20,18,0,12,4,4,4,4,4,14,0,0,0,26,21,21,17,17,0,0,0,22,25,17,17,17,0,0,0,14,17,17,17,14,0,
   0,0,30,17,30,16,16,0,0,0,13,19,15,1,1,0,0,0,22,25,16,16,16,0,0,0,14,16,14,1,30,0,8,8,28,8,8,9,6,0,0,0,17,17,17,19,13,0,0,0,17,17,17,10,4,0,0,0,17,17,21,21,10,0,
   0,0,17,10,4,10,17,0,0,0,17,17,15,1,14,0,0,0,31,2,4,8,31,0,2,4,4,8,4,4,2,0,4,4,4,4,4,4,4,0,8,4,4,2,4,4,8,0,0,4,2,31,2,4,0,0,0,4,8,31,8,4,0,0,
   14,17,16,16,17,14,4,0,10,0,17,17,17,19,13,0,2,4,14,17,31,16,14,0,4,10,14,1,15,17,15,0,10,0,14,1,15,17,15,0,8,4,14,1,15,17,15,0,4,0,14,1,15,17,15,0,0,0,14,16,17,14,4,0,
   4,10,14,17,31,16,14,0,10,0,14,17,31,16,14,0,8,4,14,17,31,16,14,0,10,0,12,4,4,4,14,0,4,10,12,4,4,4,14,0,4,2,12,4,4,4,14,0,10,0,14,17,17,31,17,0,4,0,14,17,17,31,17,0,
   4,8,31,16,30,16,31,0,0,0,26,5,30,20,11,0,15,20,20,22,28,20,23,0,4,10,0,14,17,17,14,0,10,0,0,14,17,17,14,0,4,2,0,14,17,17,14,0,4,10,17,17,17,19,13,0,8,4,17,17,17,19,13,0,
   10,0,17,17,15,1,14,0,10,0,14,17,17,17,14,0,10,0,17,17,17,17,14,0,0,0,14,19,21,25,14,0,6,9,8,28,8,30,25,0,14,19,19,21,25,25,14,0,0,0,10,4,10,0,0,0,2,5,4,14,4,8,16,0,
   2,4,14,1,15,17,15,0,4,8,12,4,4,4,14,0,4,8,0,14,17,17,14,0,2,4,17,17,17,19,13,0,5,10,22,25,17,17,17,0,5,10,17,25,21,19,17,0,14,1,15,17,15,0,14,0,14,17,17,17,14,0,14,0,
   4,0,4,8,16,17,14,0,4,14,21,4,4,4,0,0,0,4,4,4,21,14,4,0,18,20,8,22,9,2,7,0,18,20,10,22,10,15,2,0,4,0,0,4,4,4,4,0,0,5,10,20,10,5,0,0,0,20,10,5,10,20,0,0,
   14,16,14,1,17,14,4,0,0,14,16,14,1,14,4,0,14,0,14,16,23,17,14,0,14,0,15,17,15,1,14,0,4,0,14,4,4,4,14,0,2,4,14,17,17,31,17,0,4,10,14,17,17,31,17,0,8,4,14,17,17,31,17,0,
   14,17,23,21,23,17,14,0,0,0,0,12,4,4,14,0,31,9,8,8,8,8,28,0,0,0,4,10,17,17,31,0,0,0,4,10,17,17,17,0,0,31,0,14,0,31,0,0,17,10,31,4,31,4,4,0,0,31,10,10,10,10,10,0,
   14,4,14,21,14,4,14,0,4,21,21,21,21,14,4,0,0,0,0,13,18,18,13,0,0,0,10,10,4,10,4,0,0,14,8,4,10,18,12,0,0,0,14,16,28,16,14,0,5,10,14,1,15,17,15,0,5,10,14,17,17,31,17,0,
   4,6,8,8,4,2,4,0,0,0,22,9,9,9,1,0,0,0,6,9,31,18,12,0,0,0,18,20,24,20,18,0,0,0,16,8,4,10,17,0,8,12,16,12,16,12,2,0,0,0,7,12,18,12,0,0,0,0,14,16,12,2,6,0,
   0,0,14,4,4,4,2,0,0,0,18,9,9,5,6,0,4,10,31,16,30,16,31,0,10,0,31,16,30,16,31,0,4,2,31,16,30,16,31,0,0,0,4,21,21,14,4,0,2,4,14,4,4,4,14,0,4,10,14,4,4,4,14,0,
   10,0,14,4,4,4,14,0,0,0,27,17,17,21,10,0,4,8,0,13,18,18,13,0,2,4,14,16,28,16,14,0,2,4,22,9,9,9,1,0,2,4,27,17,17,21,10,0,8,4,14,4,4,4,14,0,28,20,28,0,0,0,0,0,
   2,4,14,17,17,17,14,0,0,0,14,17,30,17,30,16,4,10,14,17,17,17,14,0,8,4,14,17,17,17,14,0,5,10,0,14,17,17,14,0,5,10,14,17,17,17,14,0,0,0,17,17,19,29,16,16,0,12,18,18,28,16,16,16,
   0,0,7,4,4,20,8,0,0,2,26,2,0,0,0,0,4,10,17,17,17,17,14,0,8,4,17,17,17,17,14,0,0,4,14,20,21,14,4,0,2,4,17,17,10,4,4,0,2,4,17,17,15,1,14,0,2,4,17,17,17,17,14,0,
   28,8,14,9,14,8,28,0,4,4,31,4,4,0,31,0,0,14,17,31,17,17,14,0,0,0,0,11,21,26,0,0,0,0,14,17,17,10,27,0,21,10,21,10,21,10,21,10,31,16,8,4,8,16,31,0,0,0,31,10,10,10,19,0,
   16,8,24,10,22,15,2,0,0,10,27,31,14,14,4,0,0,4,14,31,14,4,0,0,4,14,14,27,27,4,14,0,4,14,31,31,21,4,14,0,0,0,4,0,31,0,4,0,0,0,0,0,0,0,0,0,31,31,31,31,31,31,31,31]);

var screen2mem2 = [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,
            64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79];

var screen2mem4 = [ 0,1,2,3, 8,9,10,11,12,13,14,15,   24,25,26,27,28,29,30,31,
                    64,65,66,67, 72,73,74,75,76,77,78,79, 88,89,90,91,92,93,94,95,
                    4,5,6,7, 16,17,18,19,20,21,22,23, 32,33,34,35,36,37,38,39,
                    68,69,70,71, 80,81,82,83,84,85,86,87, 96,97,98,99,100,101,102,103 ];


function CharacterImage(ctx,_scale,data,index){
   var _ink = -1;
   var _paper = -1;
   var _index = index;
   var _data = data;
   var _scale = _scale;
   var _imgData=ctx.createImageData(5*_scale,8*_scale);

   function redraw(){
      for(var rw=0; rw<8; rw++){
         var px = _data[_index+rw];
         for(var clm=4; clm>=0; clm--){
            var c=(px&0x01)?_ink:_paper;
            px>>=1;
            for(var x=0; x<_scale; x++){
               for(var y=0; y<_scale; y++){
                  var ix=((rw*_scale+y)*5*_scale+(clm*_scale+x))*4;
                  _imgData.data[ix++]=c;
                  _imgData.data[ix++]=c;
                  _imgData.data[ix++]=c;
                  _imgData.data[ix++]=255;
               }
            }
         }
      }
   }
   this.invalidate = function(){
      _ink=-1;
   }
   this.getImgData = function(ink,paper){
      if(ink!=_ink || paper!=_paper) {
         _ink=ink;
         _paper=paper;
         redraw();
      }
      return _imgData;
   }
}

function Display(ctx,nl){
   var _debug= false;   // when true, display refreshes immediately, to help debugging.

   var _numLines;
   var _chargap=2;
   var _numColumns;
   var _scale;
   var _offsetx;
   var _offsety;
   var _ink = 32;
   var _paper = 180;
   var _backgrnd = 212;

   var _cursorPos=0; // cursor position
   var _cursorState; //set if cursor is on
   var _cursorUl; //set if underline on
   var _cursorFl; //set if cursor flashing
   var _cursorTimer; //set if blinked on right now
   var _addrincr; //set if address auto increment
   var _isOn = false;

   var _scrptr = 0;  //memory pointer to screen
   var _udgptr = 0;  //memory pointer to udg data
   var _ptrToScreen=true;  // set if data to screen, false if to udg
   var _needsRefresh=true;  // set when screen contents has changed and yet to be shown

   var _context = ctx;
   var _cdata;
   var _screen2mem;
   var _mem2screen = new Array();
   var _displaydata = new Uint8Array(new ArrayBuffer(128));
   var _udgdata = new Uint8Array(new ArrayBuffer(64));
   var _chars = [];
   var _contrast = 5;
   var _timeOfNextCursorFlash;
   var _cursorFlashSpeed = 650;

   function init(nl){
      _numLines = nl;
      _chargap=2;
      _numColumns = _numLines==4 ? 20: 16;
      _scale= _numLines==4 ? 2: 3;
      _offsetx = _numLines==4 ? 41 : 24;
      _offsety = _numLines==4 ? 39 : 47; // 72 for org1;
      _cdata = (_numLines==4)?char4:char2;
      _screen2mem = (_numLines==4) ? screen2mem4 : screen2mem2;
      for( var i=0; i<8; i++){
         _chars[i] = new CharacterImage(_context,_scale,_udgdata,i*8);
      }
      for( var i=8; i<256; i++){
         _chars[i] = new CharacterImage(_context,_scale,_cdata,Math.max((i-32)*8,0));
      }
      for( var i=0; i<128; i++){
         _mem2screen[i]=false;
      }
      for( var i=0; i<_screen2mem.length; i++){
         _mem2screen[_screen2mem[i]]=true;
      }
      _needsRefresh=true;
      _timeOfNextCursorFlash = Date.now();
   }
   init(nl);

   function setContrast(){
      _paper = _backgrnd-_contrast*_contrast;
      _ink =  (10-_contrast)*(10-_contrast);
      _needsRefresh = true;
   }

   this.increaseContrast = function(){
      if( _isOn && _contrast<10 ) {
         _contrast++;
         setContrast();
      }
   }

   this.decreaseContrast = function(){
      if( _isOn && _contrast>0 ) {
         _contrast--;
         setContrast();
      }
   }

   this.refresh=function(force){
      var time = Date.now();
      if( time>_timeOfNextCursorFlash ){
         _timeOfNextCursorFlash = Math.max(_timeOfNextCursorFlash+_cursorFlashSpeed, time);
         _needsRefresh = true;
         _cursorTimer=!_cursorTimer;
         if(_debug) this.refresh();
      }

      if( !_needsRefresh && !force) return;
      _context.fillStyle = "rgb("+_backgrnd+","+_backgrnd+","+_backgrnd+")";
      _context.fillRect(_offsetx,_offsety,_numColumns*(_scale*5+_chargap)-_chargap, _numLines*(_scale*8+_chargap)-_chargap);
      if(_isOn){
         var c = 0;
         for( var line=0; line<_numLines; line++){
            for( var col=0; col<_numColumns; col++){
               var addr = _screen2mem[c++];
               var ch = _displaydata[addr];
               var x = _offsetx+col*(5*_scale+_chargap);
               var y = _offsety+line*(8*_scale+_chargap);
               _context.putImageData(_chars[ch].getImgData(_ink,_paper),x,y);
               //add cursor
               if( _cursorState && _cursorPos==addr){
                  if(_cursorFl && _cursorTimer){
                     // draw block cursor
                     _context.fillStyle = "rgb("+_ink+","+_ink+","+_ink+")";
                     _context.fillRect(x,y,_scale*5, _scale*8);
                  }else if(_cursorUl){
                     // draw underline
                     _context.fillStyle = "rgb("+_ink+","+_ink+","+_ink+")";
                     _context.fillRect(x,y+_scale*7,_scale*5, _scale);
                  }
               }
            }
         }
      }
      _needsRefresh = false;
   }

   this.isOn = function(){
      return _isOn;
   }

   this.switchOff = function(){
      _isOn=false;
      _needsRefresh = true;
      if(_debug) this.refresh();
   }

   this.switchOn = function(){
      _cursorPos=0;
      _cursorState=true;
      _cursorUl=false;
      _cursorFl=false;
      _cursorTimer=false;
      _addrincr=false;
      for( var i=0; i<64; i++) _udgdata[i]=0;
      for( var i=0; i<128; i++) _displaydata[i]=32;
      for( var i=0; i<8; i++) _chars[i].invalidate();
      _timeOfNextCursorFlash = Date.now();
      _isOn=true;
      _needsRefresh = true;
      if(_debug) this.refresh();
   }

   this.command = function(databyte){
      if( (databyte&0x80)!=0 ){
         //1AAAAAAA  Set display offset to AAAAAAA
         if( _ptrToScreen ){
            _cursorPos = databyte&0x7f;
            _scrptr = databyte&0x7f;
            _needsRefresh |= _cursorState;
         }else{
         }
         _ptrToScreen=true;
      }else if( (databyte&64)!=0 ){
         //01AAAAAA  Set databyte index to character generator offset AAAAAA
         _udgptr = databyte&63;
         _ptrToScreen=false;
      }else if( (databyte&32)!=0 ){
         //001BLHxx  byte/nibble mode, 2/4 line, 8/11 raster mode
         // ignore this for now
      }else if( (databyte&16)!=0 ){
         //0001SDxx  Move cursor/display to the left/right
         if( (databyte&8)==0 ){
            if((databyte&4)!=0){
               _cursorPos++;
            }else{
               _cursorPos--;
            }
            _needsRefresh = true;
         }else{
            // ignore move display for now
         }
      }else if( (databyte&8)!=0 ){
         // 00001EUF enable/disable cursor, set underline, set flashing
         _cursorState = (databyte&4)!=0;
         _cursorUl = (databyte&2)!=0;
         _cursorFl = (databyte&1)!=0;
         _needsRefresh = true;
      }else if( (databyte&4)!=0 ){
         // 000001AD  address auto-increment/decrement, display auto-increment/decrement
         _addrincr = (databyte&2)!=0;
         // ignore display increment for now
      }else if( (databyte&2)!=0 ){
         // 0000001x cursor to home
         _cursorPos = 0;
         // cancel display offset (ignore for now)
         // Prepare for text writes to databyte port??
         _needsRefresh = true;
      }else if( (databyte&1)!=0 ){
         // 00000001 clear display memory
         for( var i=0; i<128; i++ ) _displaydata[i]=32;
         // cursor to home
         _cursorPos = 0;
         // cancel display offset (ignore for now)
         _scrptr = 0;
         // Prepare for text writes to databyte port??
         _needsRefresh = true;
      }
   }

   this.setData = function(databyte){
      if( _ptrToScreen ){
         _displaydata[_scrptr]=databyte;
         if(_mem2screen[_scrptr]){
            _needsRefresh = true;
            if(_debug) this.refresh();
         }
         if(_addrincr){
            _scrptr++;
            if( _numLines==4 && _scrptr==40 ) _scrptr = 64;
            _scrptr&=127;
         }
      }else{
         _udgdata[_udgptr]=databyte;
         _chars[_udgptr>>3].invalidate();
         _udgptr++;
         _udgptr&=63;
         _needsRefresh = true;
         if(_debug) this.refresh();
      }
   }

   this.getData = function(){
      var t;
      if( _ptrToScreen ){
         t=_displaydata[_scrptr];
         _scrptr++;
         _scrptr&=127;
      }else{
         t=_udgdata[_udgptr];
         _udgptr++;
         _udgptr&=63;
      }
      return t;
   }

   this.getSnapshotData = function(arr){
      var arr2 = [_numLines, _cursorPos, _scrptr, _udgptr,
                  _cursorState?1:0, _cursorUl?1:0, _cursorFl?1:0, _cursorTimer?1:0,
                  _addrincr?1:0, _isOn ?1:0, _ptrToScreen?1:0
                 ];
      var ln = arr.length;
      for( var i=0; i<arr2.length; i++) arr[ln++] = arr2[i];
      for( var i=0; i<_displaydata.length; i++) arr[ln++] = _displaydata[i];
      for( var i=0; i<_udgdata.length; i++) arr[ln++] = _udgdata[i];
   }
   this.applySnapshotData = function(snapshot){
      init(snapshot.readByte());
      _cursorPos = snapshot.readByte();
      _scrptr = snapshot.readByte();
      _udgptr = snapshot.readByte();

      _cursorState = snapshot.readByte()!=0;
      _cursorUl = snapshot.readByte()!=0;
      _cursorFl = snapshot.readByte()!=0;
      _cursorTimer = snapshot.readByte()!=0;

      _addrincr= snapshot.readByte()!=0;
      _isOn = snapshot.readByte()!=0;
      _ptrToScreen = snapshot.readByte()!=0;
      for( var i=0; i<_displaydata.length; i++) _displaydata[i] = snapshot.readByte();
      for( var i=0; i<_udgdata.length; i++) _udgdata[i] = snapshot.readByte();
   }
}
