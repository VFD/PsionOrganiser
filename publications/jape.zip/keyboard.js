'use strict';

var KeyboardLayout = {
	"Normal"	: 0,
	"AlphaPos" : 1,
	"Pos200"	: 2
}

var coor2line = [
	[-1, 0, 0, 0, 0, 0],
	[ 1, 2, 3, 6, 4, 5],
	[ 1, 2, 3, 6, 4, 5],
	[ 1, 2, 3, 6, 4, 5],
	[ 1, 2, 3, 6, 4, 5],
	[ 1, 2, 3, 6, 4, 5]
];
var coor2mask = [
	[	-1, 0x04, 0x08, 0x10, 0x20, 0x40],
	[ 0x40, 0x40, 0x40, 0x40, 0x40, 0x40],
	[ 0x20, 0x20, 0x20, 0x20, 0x20, 0x20],
	[ 0x10, 0x10, 0x10, 0x10, 0x10, 0x10],
	[ 0x08, 0x08, 0x08, 0x08, 0x08, 0x08],
	[ 0x04, 0x04, 0x04, 0x04, 0x04, 0x04]
];

var key2grid = [  // keyname : line, mask, shifttype (0=no shift on Psion, 1=shift on Psion, 2=use keyb shift)
{  //normal layout
	"Escape" : [-1,0,2],	  "Esc" : [-1,0,2],  //ON/CLEAR
	"F1" : [0,0x04,2],	// MODE
	"ArrowUp" : [0,0x08,2],		  "Up" : [0,0x08,2],
	"ArrowDown" : [0,0x10,2],	  "Down" : [0,0x10,2],
	"ArrowLeft" : [0,0x20,2],	  "Left" : [0,0x20,2],
	"ArrowRight" : [0,0x40,2],	 "Right" : [0,0x40,2],
	"a" : [1,0x40,0],  "A" : [1,0x40,0],  "<" : [1,0x40,1],
	"b" : [2,0x40,0],  "B" : [2,0x40,0],  ">" : [2,0x40,1],
	"c" : [3,0x40,0],  "C" : [3,0x40,0],  "(" : [3,0x40,1],
	"d" : [6,0x40,0],  "D" : [6,0x40,0],  ")" : [6,0x40,1],
	"e" : [4,0x40,0],  "E" : [4,0x40,0],  "%" : [4,0x40,1],
	"f" : [5,0x40,0],  "F" : [5,0x40,0],  "/" : [5,0x40,1],
	"g" : [1,0x20,0],  "G" : [1,0x20,0],  "=" : [1,0x20,1],
	"h" : [2,0x20,0],  "H" : [2,0x20,0],  "\"": [2,0x20,1],
	"i" : [3,0x20,0],  "I" : [3,0x20,0],  "7" : [3,0x20,1],
	"j" : [6,0x20,0],  "J" : [6,0x20,0],  "8" : [6,0x20,1],
	"k" : [4,0x20,0],  "K" : [4,0x20,0],  "9" : [4,0x20,1],
	"l" : [5,0x20,0],  "L" : [5,0x20,0],  "*" : [5,0x20,1],
	"m" : [1,0x10,0],  "M" : [1,0x10,0],  "," : [1,0x10,1],
	"n" : [2,0x10,0],  "N" : [2,0x10,0],  "$" : [2,0x10,1],
	"o" : [3,0x10,0],  "O" : [3,0x10,0],  "4" : [3,0x10,1],
	"p" : [6,0x10,0],  "P" : [6,0x10,0],  "5" : [6,0x10,1],
	"q" : [4,0x10,0],  "Q" : [4,0x10,0],  "6" : [4,0x10,1],
	"r" : [5,0x10,0],  "R" : [5,0x10,0],  "-" : [5,0x10,1],
	"s" : [1,0x08,0],  "S" : [1,0x08,0],  ";" : [1,0x08,1],
	"t" : [2,0x08,0],  "T" : [2,0x08,0],  ":" : [2,0x08,1],
	"u" : [3,0x08,0],  "U" : [3,0x08,0],  "1" : [3,0x08,1],
	"v" : [6,0x08,0],  "V" : [6,0x08,0],  "2" : [6,0x08,1],
	"w" : [4,0x08,0],  "W" : [4,0x08,0],  "3" : [4,0x08,1],
	"x" : [5,0x08,0],  "X" : [5,0x08,0],  "+" : [5,0x08,1],
	"y" : [3,0x04,0],  "Y" : [3,0x04,0],  "0" : [3,0x04,1],
	"z" : [6,0x04,0],  "Z" : [6,0x04,0],  "." : [6,0x04,1],
	"Shift" : [1,0x04,2],
	"Delete" : [2,0x04,2],	 "Del" : [2,0x04,2],
	"Backspace" : [2,0x04,2],
	" " : [4,0x04,2],		"Spacebar" : [4,0x04,2],
	"Enter" : [5,0x04,2],	// EXE
},
{  //alphapos layout
	"Escape" : [-1,0,2],  "Esc" : [-1,0,2],  //ON/CLEAR
	"F1" : [0,0x04,2],	// MODE
	"ArrowUp" : [0,0x08,2],	  "Up" : [0,0x08,2],
	"ArrowDown" : [0,0x10,2],	"Down" : [0,0x10,2],
	"ArrowLeft" : [0,0x20,2],	"Left" : [0,0x20,2],
	"ArrowRight" : [0,0x40,2],  "Right" : [0,0x40,2],
	"a" : [1,0x40,0],  "A" : [1,0x40,0],
	"b" : [2,0x40,0],  "B" : [2,0x40,0],
	"c" : [3,0x40,0],  "C" : [3,0x40,0],
	"d" : [6,0x40,0],  "D" : [6,0x40,0],  "7" : [6,0x40,1],
	"e" : [4,0x40,0],  "E" : [4,0x40,0],  "8" : [4,0x40,1],
	"f" : [5,0x40,0],  "F" : [5,0x40,0],  "9" : [5,0x40,1],
	"g" : [1,0x20,0],  "G" : [1,0x20,0],
	"h" : [2,0x20,0],  "H" : [2,0x20,0],
	"i" : [3,0x20,0],  "I" : [3,0x20,0],
	"j" : [6,0x20,0],  "J" : [6,0x20,0],  "4" : [6,0x20,1],
	"k" : [4,0x20,0],  "K" : [4,0x20,0],  "5" : [4,0x20,1],
	"l" : [5,0x20,0],  "L" : [5,0x20,0],  "6" : [5,0x20,1],
	"m" : [1,0x10,0],  "M" : [1,0x10,0],
	"n" : [2,0x10,0],  "N" : [2,0x10,0],
	"o" : [3,0x10,0],  "O" : [3,0x10,0],
	"p" : [6,0x10,0],  "P" : [6,0x10,0],  "1" : [6,0x10,1],
	"q" : [4,0x10,0],  "Q" : [4,0x10,0],  "2" : [4,0x10,1],
	"r" : [5,0x10,0],  "R" : [5,0x10,0],  "3" : [5,0x10,1],
	"s" : [1,0x08,0],  "S" : [1,0x08,0],
	"t" : [2,0x08,0],  "T" : [2,0x08,0],
	"u" : [3,0x08,0],  "U" : [3,0x08,0],
	"v" : [6,0x08,0],  "V" : [6,0x08,0],  "0" : [6,0x08,1],
	"w" : [4,0x08,0],  "W" : [4,0x08,0],  "." : [4,0x08,1],
	"x" : [5,0x08,0],  "X" : [5,0x08,0],  "-" : [5,0x08,1],
	"y" : [3,0x04,0],  "Y" : [3,0x04,0],
	"z" : [6,0x04,0],  "Z" : [6,0x04,0],
	"Shift" : [1,0x04,2],
	"Delete" : [2,0x04,2],	"Del" : [2,0x04,2],
	"Backspace" : [2,0x04,2],
	" " : [4,0x04,2],			 "Spacebar" : [4,0x04,2],
	"Enter" : [5,0x04,2],	// EXE
},
{  //pos layout
	"Escape" : [-1,0,2],  "Esc" : [-1,0,2],  //ON/CLEAR
	"7" : [0,0x04,2],	// MODE
	"8" : [0,0x10,2],
	"9" : [0,0x40,2],
	"F1" : [1,0x40,2],
	"F2" : [1,0x20,2],	"ArrowUp" : [1,0x20,2],	"Up" : [1,0x20,2],
	"4" : [2,0x20,2],
	"5" : [6,0x20,2],
	"6" : [5,0x20,2],
	"F3" : [1,0x10,2],	"ArrowDown" : [1,0x10,2],	"Down" : [1,0x10,2],
	"F4" : [1,0x08,2],	"ArrowLeft" : [1,0x08,2],	"Left" : [1,0x08,2],
	"1" : [2,0x08,2],
	"2" : [6,0x08,2],
	"3" : [5,0x08,2],
	"0" : [3,0x04,2],
	"Enter" : [1,0x04,2],
	"." : [4,0x04,2],
}
];


function Keyboard(layout){
	var _counter = 0;
	var _pressedKeys = {};  // [event.code]=event.key
	var _keyLinesGrid = [0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff];
	var _keyLinesKeyb = [0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff];
	var _keyONGrid = false;
	var _keyONKeyb = false;
	var _key2grid = key2grid[layout];
	var _shiftLine = _key2grid.Shift ? _key2grid.Shift[0] : 0;
	var _shiftMask = _key2grid.Shift ? _key2grid.Shift[1] : 0;
	var _disabled = false;

	this.getKeyStat = undefined;

	this.clear = function(){
		_pressedKeys = {};
		for( var i=0; i<8; i++)
			_keyLinesGrid[i] = _keyLinesKeyb[i] = 0xff;
	}

	this.incrementCounter = function(){ _counter++; }
	this.resetCounter = function(){ _counter = 0; }
	this.counterHasOverflowed = function(){ return (_counter&0x1000)!=0; }
	this.isOnPressed = function(){
		var r = !_disabled && (_keyONGrid || _keyONKeyb);
		return r;
	}
	this.readPort5 = function(){
		var b = 0x7c;
		if( !_disabled ) {
			for( var a=0, m=1; a<7; a++, m<<=1){
				if( (_counter&m)==0 ) b &= _keyLinesGrid[a]&_keyLinesKeyb[a];
			}
			if( _keyONGrid || _keyONKeyb ) b |= 0x80;
	  }
		if( this.counterHasOverflowed() ) b |= 2;
		return b;
	}

	this.doGrid = function( row, col, down){
		if( row==0 && col==0 ) {
			_keyONGrid=down;
		}else {
			var line = coor2line[row][col];
			var mask = coor2mask[row][col];
			if(down){
				_keyLinesGrid[line] &= 0x7f-mask;
			}else{
				_keyLinesGrid[line] |= 0x80+mask;
			}
		}
	}

	this.doKeys = function( ){
		for( var i=0; i<8; i++) _keyLinesKeyb[i] = 0xff;
		_keyONKeyb = false;
		var shiftListed = false;
		var otherKeysPressed = false;
		for(var k in _pressedKeys){
			var v = _pressedKeys[k];
			if(v) {
				var key = v.key;
				var shift = v.shift;
				if( key==="Shift" ) {
					shiftListed = true;
					continue;
				}
				// convert key to line/mask and shift state
				var g = _key2grid[key];
				if( g ){
					if( g[2]!=2 ) {
						var ks = this.getKeyStat ? this.getKeyStat() : 0;
						shift = (g[2]==1) != ((ks&0x40)!=0);
					}
					if( g[0]<0 ) _keyONKeyb = true;
					_keyLinesKeyb[g[0]] &= 0x7f-g[1];
					if( shift ){
						_keyLinesKeyb[_shiftLine] &= 0x7f-_shiftMask;
					}
					otherKeysPressed = true;
				}else{
					console.log("Unused key: "+key);
				}
			}
		}
		if( shiftListed && !otherKeysPressed ){
			_keyLinesKeyb[_shiftLine] &= 0x7f-_shiftMask;
		}
	}

	this.disable = function(){ _disabled=true;  }
	this.enable  = function(){ _disabled=false; }


	// --------------- keyboard/mouse/touch events ---------------

	this.handleKeyDown = function(event){
		var c = event.code;
		if( c==="ShiftLeft" || c==="ShiftRight" ) c = "Shift";
		if( !_pressedKeys[c] ){
			_pressedKeys[c] = { "key" : event.key, "shift" : event.shiftKey }
			this.doKeys();
		}
		if( !_disabled ) event.preventDefault();
	}
	this.handleKeyUp = function(event){
		var c = event.code;
		if( c==="ShiftLeft" || c==="ShiftRight" ) c = "Shift";
		if( _pressedKeys[c] ){
			_pressedKeys[c] = undefined;  // faster than delete
			this.doKeys();
		}
		if( !_disabled ) event.preventDefault();
	}

	this.handleItemPress = function(item,isDown,isMouse){
		if( item.type=="key" ){
			// row:r, column:c, minx:5+50*c, maxx:5+50*(c+1), miny:162+50*r, maxy:162+50*(r+1)
			this.doGrid(item.row, item.column, isDown);
		}
	}
}
