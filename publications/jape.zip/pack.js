'use strict';

var FlashDriver = new BinaryFile("other/fdrive19.bin",false);

var _debug = false;

var PackPin = {
   SCLK   : 0x01,
   SMR      : 0x02,
   SPGM_B : 0x04,
   SOE_B  : 0x08,
   SVPP   : 0x10,
   V21V   : 0x20,
   P2DDR  : 0x40,
}

// 8k, 16k
function PackCounterLinear(ln){
   var _address = 0;
   var _length = ln;
   this.length = function(){ return _length; }
   this.reset = function(){ _address = 0; }
   this.address = function(){ return _address; }
   this.controlPort = function(pins, databus ){
      if( (pins & PackPin.SMR)!=0 ){   // SMR, reset counters
         _address = 0;
      }
      if( (pins & PackPin.SCLK)!=(_address&1) ){ //SCLK, increase address
         ++_address;
         _address %= _length;
      }
   }
}

// 32k, 64k
function PackCounterPaged(ln){
   var _address = 0;
   var _length = ln;
   var _prevPins = 0;
   this.length = function(){ return _length; }
   this.reset = function(){ _address = 0; }
   this.address = function(){ return _address; }
   this.controlPort = function(pins, databus ){
      // 21V, SVPP, SOE_B, SPGM_B, SMR, SCLK
      if( (pins & PackPin.SMR)!=0 ){   // SMR, reset counters
         _address = 0;
      }
      if( (pins & PackPin.SCLK)!=(_address&1) ){ //SCLK, increase address
         _address = (_address & 0xffff00)|(((_address & 0xff)+1)&0xff);
      }
      if( (pins & ( /*PackPin.SVPP |*/ PackPin.SPGM_B | PackPin.SMR ) )==0 && (_prevPins & PackPin.SPGM_B)!=0 ){ // S_PGM_B became low, SMR low, increase page
         _address += 0x100;
         _address %= _length;
      }
      _prevPins = pins;
   }
}

// 128k
function PackCounterSegmented(ln){
   var _address = 0;
   var _length = ln;
   var _prevPins = 0;
   this.length = function(){ return _length; }
   this.reset = function(){ _address = 0; }
   this.address = function(){ return _address; }
   this.controlPort = function(pins, databus ){
      // 21V, SVPP, SOE_B, SPGM_B, SMR, SCLK
      if( (pins & PackPin.SMR)!=0 ){   // SMR, reset counters
         _address -= _address&0x3FFF;
      }
      if( (pins & PackPin.SCLK)!=(_address&1) ){ //SCLK, increase address
         _address = (_address & 0xffff00)|(((_address & 0xff)+1)&0xff);
      }
      if( (pins & ( PackPin.SVPP | PackPin.SPGM_B | PackPin.SMR ) )==0 && (_prevPins & PackPin.SPGM_B)!=0 ){ // S_PGM_B became low, SMR low, increase page
         var counterM = _address&0x3F00;
         var counterHL = _address - counterM;
         _address = counterHL|((counterM+0x100)&0x3f00);
      }
      if( (pins & ( PackPin.SVPP | PackPin.SOE_B | PackPin.S_PGM_B | PackPin.SMR )) == (PackPin.SOE_B | PackPin.SMR) ){ // SOE_B high, (S_PGM_B low), SMR high, set segment address
         _address = ( _address&0x3FFF ) + (databus << 14);
         if( _address>=_length ) _address &= _length-1; // assumes length is a power of 2.
      }
      _prevPins = pins;
   }
}







var CommandType = {
   Read : 0,
   Write : 1,
   IDByte1 : 2,
   IDByte2 : 3,
   Other : 4
}

function logpins(pins){
   var s = "Pins: "+pins+"  ";
   s += "P2DDR "+ ((pins&PackPin.P2DDR)!=0?1:0);
   s += ", V21V "+ ((pins&PackPin.V21V)!=0?1:0);
   s += ", SVPP "+ ((pins&PackPin.SVPP)!=0?1:0);
   s += ", SOE_B "+ ((pins&PackPin.SOE_B)!=0?1:0);
   s += ", SPGM_B "+ ((pins&PackPin.SPGM_B)!=0?1:0);
   s += ", SMR "+ ((pins&PackPin.SMR)!=0?1:0);
   s += ", SCLK "+ ((pins&PackPin.SCLK)!=0?1:0);
   return s;
}

function PackControllerEprom()
{
   this.getHardwareID = function(){ return -1; }
   this.controlPort = function( pins, databus ){
      // 21V, SVPP, SOE_B, SPGM_B, SMR, SCLK
      if( (pins & PackPin.SOE_B)==0 ){
         return CommandType.Read;
      }else if( (pins&(PackPin.SVPP | PackPin.SOE_B | PackPin.SPGM_B))==(PackPin.SVPP | PackPin.SOE_B) ){
         // Don't bother to check that 21V is actually present. Assume that any vpp voltage is enough.
         return CommandType.Write;
      }
      return CommandType.Other;
   }
}

function PackControllerDummy()
{
   this.getHardwareID = function(){ return -1; }
   this.controlPort = function( pins, databus ){ return CommandType.Other; }
}

function PackControllerRom()
{
   this.getHardwareID = function(){ return -1; }
   this.controlPort = function( pins, databus ){
      // 21V, SVPP, SOE_B, SPGM_B, SMR, SCLK
      if( (pins & PackPin.SOE_B)==0 ){
         return CommandType.Read;
      }
      return CommandType.Other;
   }
}

function PackControllerRam()
{
   this.getHardwareID = function(){ return 0x0101; }
   this.controlPort = function( pins, databus ){
      // 21V, SVPP, SOE_B, SPGM_B, SMR, SCLK
      if( (pins&( PackPin.SOE_B | PackPin.SMR | PackPin.SCLK )) == PackPin.SMR  ){  // read hardware byte1
         return CommandType.IDByte1;
      }else if( (pins & ( PackPin.SOE_B | PackPin.SMR | PackPin.SCLK ))== (PackPin.SMR | PackPin.SCLK) ){   // read hardware byte2
            return CommandType.IDByte2;
      }else if( ( pins & PackPin.SOE_B )==0 ){
         return CommandType.Read;
      }else if( (pins&(PackPin.SOE_B | PackPin.SMR )) == PackPin.SOE_B ){
         return CommandType.Write;
      }
      return CommandType.Other;
   }
}


function PackControllerFlash()
{
   this.getHardwareID = function(){ return 0xB489; }
   var Mode = {
      Read : 0,
      Verify : 1,
      Write : 2,
      Erase: 3,
   }
   var _mode = Mode.Read;
   this.controlPort = function( pins, databus ){
      // 21V, SVPP, SOE_B, SPGM_B, SMR, SCLK
      //FlashPack unknown: ctrl=56 111000  data=127
      //FlashPack unknown: ctrl=52 110100  data=127
      //FlashPack unknown: ctrl=40 010100  data=255

      if( (pins & PackPin.SVPP)!=0 ){
         if( _mode==Mode.Write ){
            _mode = Mode.Read;
            if(_debug) console.log("write command")
            return CommandType.Write;
         }else if( (databus&0xff) == 0x40 ){
            _mode = Mode.Write;
            if(_debug) console.log("switch to write mode")
         }else if( (databus&0xff) == 0x00 ){
            _mode = Mode.Read;
            if(_debug) console.log("read command, high voltage")
            return CommandType.Read;
         }else if( (databus&0xff) == 0xC0 ){
            _mode = Mode.Read; // actually it is verify mode
            if(_debug) console.log("read/verify command")
            return CommandType.Read;
         }else if( (databus&0xff) == 0xFF ){
            _mode = Mode.Read; // actually it is reset mode
            if(_debug) console.log("switch to reset mode")
         }else{
            console.log("FlashPack unknown: ctrl="+pins+"  data="+databus);
         }
      }else {
         _mode = Mode.Read;
         if( (pins & (PackPin.SOE_B | PackPin.SMR)) == PackPin.SMR ){   // read hardware byte
            if(_debug) console.log("read idbyte2")
            return CommandType.IDByte2;
         }else if( (pins & (PackPin.SOE_B | PackPin.SMR)) == (PackPin.SOE_B | PackPin.SMR) ){
            if(_debug) console.log("read idbyte1")
            return CommandType.IDByte1;
         }else if( (pins & PackPin.SOE_B)==0 ){
            if(_debug) console.log("read command normal")
            return CommandType.Read;
         }else{
            console.log("FlashPack unknown: ctrl="+pins+"  data="+databus);
         }
      }
      return CommandType.Other;
   }
}

var PackTypes = {
   EPROM : 0,
   RAM   : 1,
   FLASH : 2,
   ROM   : 3,
   TOPSLOT : 4,
   DUMMY : 5
};

var PackAddressingTypes = {
   LINEAR   : 0,
   PAGED : 1,
   SEGMENTED : 2
};

function Pack(inputData, callback)
{
   var _name = "Empty";
   var _outputDataBus = 0;
   var _data; // all the current data
   var _changed = false;  // set if contents have changed
   var _controller = new PackControllerDummy();
   var _counter = new PackCounterLinear(0);
   var _inputData = inputData;
   var _isReady = false;
   var _url;
   var _blob;

   this.isReady = function(){
      if( !_isReady ){
         if( _inputData && _inputData.name && (_inputData.filename || _inputData.file ) ){
            _name = _inputData.name;
            if( !_inputData.file ){
               _inputData.file = new BinaryFile(_inputData.filename, false, function(){
                     loadOPKData( _inputData.file.getData(), _inputData.name );
                     if( callback ) callback();
                  });
            }else{
               if( _inputData.file.isReady() ){
                  loadOPKData( _inputData.file.getData(), _inputData.name );
               }
            }
         }else if( _inputData && _inputData.name && _inputData.type!=undefined && _inputData.size ){
            preparePack( _inputData.name, _inputData.type, _inputData.size );
            if( callback ) setTimeout(callback, 0);
         }else{
            _isReady = true;  // empty slot
            if( callback ) setTimeout(callback, 0);
         }
      }
      return _isReady;
   }

   this.getURL = function(){
      if( !_data ) return;
      var wu = window.webkitURL || window.URL;
      if( _url ){
         if(!_changed) return _url;
         wu.revokeObjectURL(_blob)
      }

      var ln=_data.length;
      while( _data[ln-3]==0xff ) ln--;
      var savedata = new Uint8Array(new ArrayBuffer(ln+6));
      savedata[0] = 79; // OPK
      savedata[1] = 80;
      savedata[2] = 75;
      savedata[3] = (ln-2)>>16;
      savedata[4] = ((ln-2)>>8)&0xff;
      savedata[5] = (ln-2)&0xff;
      for( var i=0; i<ln; i++) savedata[i+6] = _data[i];
      _blob = new Blob([savedata], {type: 'application/octet-stream'});
      _url = wu.createObjectURL(_blob);
      return _url;
   }

   this.name = function(){ return _name; }

   this.readByte = function(address){
      var b = address < _data.length ? _data[address] : -1;
      if(_debug) console.log("read "+_name+"["+address+"] -> "+b);
      return b;
   }

   this.writeByte = function(address, value){
      if( address >= _data.length ){
         console.log("Pack Write error");
      }else{
         if(_debug ) console.log("write "+_name+"["+address+"] <- "+value);
         _changed |= _data[address]!=value;
         _data[address] = value;
      }
   }

   this.reset = function(){
      _counter.reset();
   }

   this.writeControlPort = function(control, databus){
      var tmp = _counter.address();
      _counter.controlPort(control, databus);
      var t = _controller.controlPort(control, databus);
      if(_debug) console.log("Pack control "+control+" "+logpins(control)+" addr:"+tmp+"->"+_counter.address());

      if( t == CommandType.IDByte1 || t == CommandType.IDByte2) {
         var hardwareIDbytes = _controller.getHardwareID();
         if( hardwareIDbytes>=0 ){
            _outputDataBus = ( t == CommandType.IDByte1 ? hardwareIDbytes : (hardwareIDbytes>>8))&0xff;
         } else{
            t = CommandType.Read;
         }
      }

      if( t==CommandType.Read){
         _outputDataBus = this.readByte(_counter.address());
      }else if( t == CommandType.Write ){
         this.writeByte(_counter.address(), databus);
         return true;
      }
      return false;
   }
   this.readDataBus = function() {
      return _outputDataBus;
   }

   function preparePack( nm, tp, sz ){
      _name = nm;
      var sz1 = sz*1024;
      _data = new Uint8Array(new ArrayBuffer(sz1));
      for( var i=0; i<sz1; i++ ) _data[i] = 255;
      _changed = false;

      var paged = (sz>=32);
      var segmented = (sz>=128);
      prepareHardware(tp, segmented, paged, sz1, true);
   }
   function loadOPKData(dataOrig, nm) {
      _name = nm;
      var sz1 = dataOrig.length;
      if( sz1<16 ) { _inputData=null; alert("Pack image too small"); return; }
      if( dataOrig[0]!=79 || dataOrig[1]!=80 || dataOrig[2]!=75 ) { _inputData=null; alert("File is not a pack image!"); return; }
      var sz2 = (dataOrig[3]*256+dataOrig[4])*256+dataOrig[5];
      if( sz2+6!=sz1 && sz2+8!=sz1) { _inputData=null; alert("Inconsistent length bytes in Pack image file!"); return; }
      var t = 8*dataOrig[7];
      sz1 = t*1024;
      if( sz1 < sz2) { _inputData=null; alert("Inconsistent pack size byte in Pack image file!"); return; }

      // create contents
      _data = new Uint8Array(new ArrayBuffer(sz1));
      for( var i=6; i<dataOrig.length; i++ ) _data[i-6] = dataOrig[i];
      for( var i=dataOrig.length-6; i<sz1; i++ ) _data[i] = 255;
      _changed = false;

      // determine pack type and addressing types
      var type = PackTypes.EPROM;
      var paged = t>=32;
      var segmented = t>=128;
      if( _data[0]!=251 ){ // skip if org1 pack
         var r = _data[0];
         paged = (r&0x04)!=0;
         if( (r&0x02)==0 ) type = PackTypes.RAM;
         if( (r&0x40)==0 ) type = PackTypes.FLASH;
         segmented = _data[1]>=16;  // 128k or larger
      }
      prepareHardware(type, segmented, paged, sz1, false);
   }

   function prepareHardware(type, segmented, paged, sz1, blank) {
      var counter = null;
      if( segmented ){
         if( !paged ) Console.log("Segmented packs should be paged!");
         counter = new PackCounterSegmented(sz1);
      }else if( paged ){
         counter = new PackCounterPaged(sz1);
      }else{
         counter = new PackCounterLinear(sz1);
      }
      var controller = null;
      if( type == PackTypes.RAM ){
         controller = new PackControllerRam();
      }else if( type == PackTypes.EPROM ){
         controller = new PackControllerEprom();
      }else if( type == PackTypes.FLASH ){
         controller = new PackControllerFlash();
         if(blank) loadFlashDriver();
      }else if( type == PackTypes.TOPSLOT || type == PackTypes.ROM ){
         controller = new PackControllerRom();
      }
      if( controller == null || counter==null){
         _inputData = null;
         alert("Pack type not yet supported");
         return;
      }
      _controller = controller;
      _counter = counter;

      _isReady = true;
   }

   function loadFlashDriver(){
      var filedata = FlashDriver.getData();
      if( filedata[0]!=79 || filedata[1]!=82 || filedata[2]!=71 ){
         console.log("Invalid flashdriver file: "+FlashDriver.getName());
         return;
      }
      var len =  filedata[3]*0x100 + filedata[4];
      if( len+6 > filedata.length ){
         console.log("Invalid flashdriver file "+FlashDriver.getName()+" - incorrect length:"+len + ">"+filedata.length);
         return;
      }

      for( var i=0; i<len; i++ ) _data[i] = filedata[i+6];
      // write the correct pack size in the header
      _data[1] = _data.length / 8192;
   }

   this.isReady();
}

