'use strict';

function Ram(sizeInKb){

   var _lowAddress, _highAddress;   // address range within this memory
   var _currentBankIndex = 0x4000;  // index in _data of current RAM bank

   var _bankAddress = 0x4000;       // memory address of the banks (constant)
   var _processorRamLow = 0x40;  // low address of processor ram (constant)
   var _processorRamHigh = 0x100;  // high address of processor ram (constant)
   var _size;

   if( sizeInKb == 8 ){
      _lowAddress = 0x2000;
      _highAddress = 0x4000;
      _size = 16;
   }else if( sizeInKb == 16 ){
      _lowAddress = 0x2000;
      _highAddress = 0x6000;
      _size = 24;
   }else{ // 32, 64, 96
      _lowAddress = 0x0000;
      _highAddress = 0x8000;
      _size = sizeInKb;
   }
   var _data = new Uint8Array(new ArrayBuffer(_size*1024));

   this.read = function(address){
      if( address<_processorRamHigh && address>=_processorRamLow ){
         return _data[address];
      }else if( address>=_highAddress || address<_lowAddress ){
         return 0xff;
      }else if( address<_bankAddress){
         return _data[address];
      }else{
         return _data[address-_bankAddress+_currentBankIndex];
      }
   }
   this.write = function(address, b){
      if( address<_processorRamHigh && address>=_processorRamLow ){
         _data[address]=b;
      }else if( address>=_highAddress || address<_lowAddress ){
      }else if( address<_bankAddress){
         _data[address]=b;
      }else{
         _data[address-_bankAddress+_currentBankIndex]=b;
      }
   }
   this.nextBank = function(){
      _currentBankIndex+=0x4000;
      if(_currentBankIndex >= _data.length){
         _currentBankIndex=0x4000;
      }
   }
   this.resetBank = function(){
      _currentBankIndex=0x4000;
   }

   this.getSnapshotData = function(arr){
      var ln = arr.length;
      arr[ln++] = _data.length/1024;
      arr[ln++] = _currentBankIndex>>8;
      arr[ln++] = _currentBankIndex&0xff;
      arr[ln++] = _lowAddress>>8;
      arr[ln++] = _lowAddress&0xff;
      arr[ln++] = _highAddress>>8;
      arr[ln++] = _highAddress&0xff;
      for( var i=_processorRamLow; i<_processorRamHigh; i++) arr[ln++] = _data[i];
      for( var i=_lowAddress; i<_data.length; i++) arr[ln++] = _data[i];
   }
   this.applySnapshotData = function(snapshot){
      var s = snapshot.readByte();
      _data = new Uint8Array(new ArrayBuffer(s*1024));
      _currentBankIndex = snapshot.readWord();
      _lowAddress = snapshot.readWord();
      _highAddress = snapshot.readWord();
      for( var i=_processorRamLow; i<_processorRamHigh; i++) _data[i] = snapshot.readByte();
      for( var i=_lowAddress; i<_data.length; i++) _data[i] = snapshot.readByte();
   }
}

function Rom(data){
   var _data = data; //new Uint8Array(new ArrayBuffer(_numBytes));
   var _currentBankIndex = 0; // data index of current banks
   var _size = _data.length;
   var _lowAddress = 0x8000;  // lowest ROM address (constant)
   var _highAddress = 0x10000;  // one part highest ROM address (constant)

   this.read = function(address){
      if( address >= _lowAddress && address<_highAddress ){
         var index = address-_lowAddress;
         return index>=0x4000 || _currentBankIndex==0 ? _data[index] : _data[index+_currentBankIndex];
      }
      return -1;
   }
   this.nextBank = function(){
      _currentBankIndex += ( _currentBankIndex==0 ) ? 0x8000 : 0x4000;
      if(_currentBankIndex>=data.length) {
         _currentBankIndex=0;
      }
   }
   this.resetBank = function(){
      _currentBankIndex=0;
   }

   this.getSnapshotData = function(arr){
      var ln = arr.length;
      arr[ln++] = _currentBankIndex>>8;
      arr[ln++] = _currentBankIndex&0xff;
   }
   this.applySnapshotData = function(snapshot){
      _currentBankIndex = snapshot.readWord();
   }
}


function Memory( ramSize, romFile )
{
   var _romFile = romFile;
   var _rom;
   var _ram = new Ram(ramSize);

   this.isReady = function(){
      if( _rom ) return true;
      if( !_romFile.isReady() ) return false;
      _rom = new Rom(_romFile.getData());
      _romFile = undefined;
   }

   this.read = function(address){
      return address >= 0x8000? _rom.read(address) : _ram.read(address);
   }
   this.write = function(address, b){
      _ram.write(address, b);
   }
   this.nextrom = function(){
      _rom.nextBank();
   }
   this.nextram = function(){
      _ram.nextBank();
   }
   this.resetBank = function(){
      if(_rom) _rom.resetBank();
      _ram.resetBank();
   }

   this.getSnapshotData = function(arr){
      _rom.getSnapshotData(arr);
      _ram.getSnapshotData(arr);
   }
   this.applySnapshotData = function(snapshot){
      _rom.applySnapshotData(snapshot);
      _ram.applySnapshotData(snapshot);
   }
}

