'use strict';

// This class controls all passing of info between the various parts of the Psion
// Note that the semi-custom chip's duties are also performed by this class

function Bus(mem, dsp, kb){
   var _memory = mem;
   var _display = dsp;
   var _keyboard = kb;

   var _switched_off = true;

   var _packs = [new Pack(), new Pack(), new Pack()];

   var _OCIdue = false;
   var _NMItoCtr=true;
   var _ticksSinceNMI = 0;

   var _port2proc = 0;
   var _port2actual = 0;
   var _port2ddr = 0;
   var _port6proc = 0;
   var _port6actual = 0;
   var _port6ddr = 0;

   var _timer1_ocr = 0xffff; // = 46080;  // clock ticks per OCI interrupt. Increase for higher speed
   var _timer1_frc = 0;
   var _port5rcr = 0;
   var _timer1_csr = 0;
   var _sca_alarmhigh = false;
   //private boolean pulse_enable = false;
   var _vpp21_charged = false;

   this.onSwitchOnOff = function(){}

   this.isReady = function(){
      return _memory.isReady() && _packs[0].isReady() && _packs[1].isReady() && _packs[2].isReady();
   }
   this.getPacks = function(){
      return _packs;
   }

   // read from address in _memory/processor/semicustom chip
   this.read = function(address){
      if( address < 0x40 ){
         return this.processorRead(address);
      }else if( address < 0x100 ){
         return _memory.read(address);
      }else if( address < 0x400 ){
         return( this.semicustom(address,0,false) );
      }else{
         return _memory.read(address);
      }
   }

   // write to address in _memory/processor/semicustom chip
   this.write = function(address,b){
      if( address < 0x40 ){
         processorWrite(address,b);
      }else if( address < 0x100 ){
         _memory.write(address,b);
      }else if( address < 0x400 ){
         this.semicustom(address,b,true);
      }else{
         _memory.write(address,b);
      }
   }

   // read/write address in semicustom chip
   this.semicustom = function(address, data, write){
      if( address<0x180 ){
         // ignore
      }else if( address<0x1bf ){
         // _display
         address &= 0x181;
         if( address == 0x180 ){
            if( write ) _display.command(data);
            return 0;
         }
         if( write ){
            _display.setData(data);
            return 0;
         }
         return _display.getData();
      }else{
         //console.log("semicustom: "+address+"  "+data+"  "+write);
         address &= 0xffe0;
         switch(address){
            case 0x01c0:
            {
               this.switchOff();
               break;
            }
            case 0x0200:
            {
               //pulse enable - generate datapack 21v voltage for writing
               //pulse_enable = true;
               _vpp21_charged = true;  // we are at full charge immediately!
               break;
            }
            case 0x0240:
            {
               //pulse disable - stop generating datapack 21v voltage
               //pulse_enable = false;
               break;
            }
            case 0x0280:
            {
               //buzzer on / set 21v onto pack
               _sca_alarmhigh = true;
               break;
            }
            case 0x02c0:
            {
               //buzzer off / set 5v onto pack
               _sca_alarmhigh = false;
               break;
            }
            case 0x0300:
            {
               //reset _keyboard/clock counter
               _keyboard.resetCounter();
               break;
            }
            case 0x0340:
            {
               //increment _keyboard/clock counter
               _keyboard.incrementCounter();
               break;
            }
            case 0x0380:
            {
               //enable nmi to processor
               _NMItoCtr=false;
               break;
            }
            case 0x03c0:
            {
               //enable nmi to counter
               _NMItoCtr=true;
               break;
            }
            case 0x0360:
            {
               //reset _memory banks
               _memory.resetBank();
               break;
            }
            case 0x03a0:
            {
               //next ram
               _memory.nextram();
               break;
            }
            case 0x03e0:
            {
               //next rom
               _memory.nextrom();
               break;
            }

         }
      }
      return 0;
   }

   // read/write address in processor
   this.processorRead = function(address){
      if(address==0x15){ // port 5
         var b = _keyboard.readPort5();
         if( _vpp21_charged ) b|=2;
         return b;
      }else if(address==0x17){ // port 6, pack control
         return _port6actual;
      }else if(address==0x16){ // port 6 ddr
         return _port6ddr;
      }else if(address==0x1){ // port 2 ddr
         return _port2ddr;
      }else if(address==0x3){ // port 2
         readPort2();
         return _port2actual;
      }else if(address==0x14){
         return _port5rcr;
      }else if(address==0x08){
         return _timer1_csr;
      }else if(address==0x09){
         return (_timer1_frc>>8)&0xff;
      }else if(address==0x0A){
         return _timer1_frc&0xff;
      }else if(address==0x0B){
         return (_timer1_ocr>>8)&0xff;
      }else if(address==0x0C){
         return _timer1_ocr&0xff;
      }
      return 0;
   }

   // read/write address in processor
   function processorWrite(address, data){
      if(address==0x17){ // port 6, pack control
         _port6proc = data;
         var newp6 = ( (_port6proc&_port6ddr) + (_port6actual&(_port6ddr^0xff)))&0xff;
         if(newp6 != _port6actual){
            _port6actual = newp6;
            writePort2or6();
         }
      }else if(address==0x16){ // port 6 ddr
         if(data != _port6ddr){
            _port6ddr = data;
            writePort2or6();
         }
      }else if(address==0x1){ // port 2 ddr
         if(data != _port2ddr){
            _port2ddr = data;
            var newp2 = ( (_port2proc&_port2ddr) + (_port2actual&(_port2ddr^0xff)))&0xff;
            if( _port2actual!=newp2){
               _port2actual = newp2;
            }
            writePort2or6();
         }
      }else if(address==0x3){ // port 2
         _port2proc = data;
         var newp2 = ( (_port2proc&_port2ddr) + (_port2actual&(_port2ddr^0xff)))&0xff;
         if( _port2actual!=newp2){
            _port2actual = newp2;
            writePort2or6();
         }
      }else if(address==0x14){
         _port5rcr = data;
      }else if(address==0x08){
         _timer1_csr = data;
      }else if(address==0x09){
         _timer1_frc = (_timer1_frc&0xff) + ((data&0xff)<<8);
      }else if(address==0x0A){
         _timer1_frc = (_timer1_frc&0xff00) + (data&0xff);
      }else if(address==0x0B){
         _timer1_ocr = (_timer1_ocr&0xff) + ((data&0xff)<<8);
      }else if(address==0x0C){
         _timer1_ocr = (_timer1_ocr&0xff00) + (data&0xff);
      }
   }

   this.setPack = function(pack, slot)
   {
      if( slot>=0 && slot<=2 && _packs[slot]!==pack ){
         //_packs[slot].saveData();
         _packs[slot] = pack;
      }
   }
   function resetWarmBoot(){
      _memory.resetBank();
      _timer1_frc = 0;
      _sca_alarmhigh = false;
      _display.reset();
      this.switchOn();
   }

   this.isSwitchedOff = function(){
      return _switched_off;
   }

   this.switchOff = function(){
      _switched_off = true;
      _display.switchOff();
      this.onSwitchOnOff(false);
   }
   this.switchOn = function(){
      _switched_off = false;
      _display.switchOn();
      this.onSwitchOnOff(true);
   }

   // this is called when port 6 (control bus) or port 2 (data bus) has changed, so that packs can react
   function writePort2or6(){
      // extract the control lines
      var control = _port6actual&0x0f;
      if( (_port2ddr&0xff)!=0xff ) control |= PackPin.P2DDR;
      if(_sca_alarmhigh) control |= PackPin.SVPP;
      if(_vpp21_charged) control |= PackPin.V21V;
      var write = false;

      if( (_port6actual&0x80)!=0 || (_port6ddr&0x80)==0 ){ // if packs are powered down
         _packs[0].reset();
         _packs[1].reset();
         _packs[2].reset();
      }else{
         if( (_port6actual&0x10)==0 && (_port6ddr&0x10)!=0) write |= _packs[0].writeControlPort(control, _port2actual);
         if( (_port6actual&0x20)==0 && (_port6ddr&0x20)!=0) write |= _packs[1].writeControlPort(control, _port2actual);
         if( (_port6actual&0x40)==0 && (_port6ddr&0x40)!=0) write |= _packs[2].writeControlPort(control|PackPin.SPGM_B, _port2actual);
         else _packs[2].reset(); // does it really work this way?
      }
      if( _vpp21_charged && write){
         _vpp21_charged = false;
      }
   }

   // this is called when port 2 (data bus) is read, to make sure bus value is up to date
   function readPort2(){
      if( (_port6actual&0x80)==0 && (_port6ddr&0x80)!=0 && (_port2ddr&0xff)!=0xff ){ // if packs are powered up and port2 has input
         var r = 0;
         if( (_port6actual&0x10)==0 && (_port6ddr&0x10)!=0) r |= _packs[0].readDataBus();
         if( (_port6actual&0x20)==0 && (_port6ddr&0x20)!=0) r |= _packs[1].readDataBus();
         if( (_port6actual&0x40)==0 && (_port6ddr&0x40)!=0) r |= _packs[2].readDataBus();
         _port2actual = ( (_port2proc&_port2ddr) + (r&(_port2ddr^0xff)))&0xff;
      }
   }

   this.incFrame = function (n){
      _timer1_frc = (_timer1_frc+n)&0xffff;
      if( _timer1_frc >= _timer1_ocr){
         _OCIdue = true;
         _timer1_frc = 0;
      }
      _ticksSinceNMI += n;
   }

   this.isOCIdue = function (){
      if( !_OCIdue ) return false;
      _OCIdue = false;

      if( _switched_off && _keyboard.isOnPressed() ){
         this.switchOn();
      }

      return (_timer1_csr&8)!=0;
   }

   this.setClockAtNMI = false;
   this.clockCallback = function(){};

   this.isNMIdue = function (){
      if(_ticksSinceNMI < 921600-35) return false;
      _ticksSinceNMI = 0;

      if( _NMItoCtr ){
         _keyboard.incrementCounter();
         if( _keyboard.counterHasOverflowed() ){
            this.switchOn();
         }
         return false;
      }

      if(this.setClockAtNMI){
         this.setClockAtNMI = false;
         setClockToCurrent();
         this.clockCallback();
      }

      return true;
   }

   function setClockToCurrent(){
      if( !_nonDST ) prepareDaylightSaving();
      var cmxp = (_memory.read(0xffe8)&0xf)<8;
      var currentdate = new Date();
      // adjust for daylight saving time
      if( !cmxp && currentdate.getTimezoneOffset() != _nonDST ){
         currentdate = new Date(Date.now()-3600000);
         _memory.write(0x20A6, _memory.read(0x20A6)|0x80);
      }
      // get the time and date
      var data = [ currentdate.getFullYear()-1900,
                  currentdate.getMonth(),
                  currentdate.getDate()-1,
                  currentdate.getHours(),
                  currentdate.getMinutes(),
                  currentdate.getSeconds() ];
      // CM/XP cannot handle years > 1999
      if( cmxp ) data[0] %= 28;
      // set time and date on Psion
      for( var i=0; i<data.length; i++){
         _memory.write(0x20c5+i, data[i]);
      }
   }

   var _nonDST;
   function prepareDaylightSaving(){
      var arr = [];
      var d = new Date();
      for (var i = 0; i < 365; i+=4) {
         d.setDate(i);
         arr.push(d.getTimezoneOffset());
      }
      _nonDST = Math.max.apply(null, arr);
   }

   function getKeyStat(){
      return _memory.read(0x7B) & 0xFF; // TODO get right address
   }

   this.getSnapshotData = function(arr){
      var arr2 = [_switched_off?1:0, 0 /*unused*/, _OCIdue?1:0, _NMItoCtr?1:0, _sca_alarmhigh?1:0, _vpp21_charged?1:0,
                  _port2proc, _port2actual, _port2ddr, _port6proc, _port6actual, _port6ddr, _port5rcr,
                  _timer1_ocr>>8, _timer1_ocr&0xff, _timer1_frc>>8, _timer1_frc&0xff, _timer1_csr,
                  _ticksSinceNMI>>16, (_ticksSinceNMI>>8)&0xff, _ticksSinceNMI&0xff ];
      var ln = arr.length;
      for( var i=0; i<arr2.length; i++) arr[ln++] = arr2[i];
   }
   this.applySnapshotData = function(snapshot){
      _switched_off = snapshot.readByte()!=0;
      snapshot.readByte(); /* unused */
      _OCIdue = snapshot.readByte()!=0;
      _NMItoCtr = snapshot.readByte()!=0;
      _sca_alarmhigh = snapshot.readByte()!=0;
      _vpp21_charged = snapshot.readByte()!=0;
      _port2proc = snapshot.readByte();
      _port2actual = snapshot.readByte();
      _port2ddr = snapshot.readByte();
      _port6proc = snapshot.readByte();
      _port6actual = snapshot.readByte();
      _port6ddr = snapshot.readByte();
      _port5rcr = snapshot.readByte();
      _timer1_ocr = snapshot.readWord();
      _timer1_frc = snapshot.readWord();
      _timer1_csr = snapshot.readByte();
      _ticksSinceNMI = snapshot.readByte();
      _ticksSinceNMI = (_ticksSinceNMI<<8) + snapshot.readByte();
      _ticksSinceNMI = (_ticksSinceNMI<<8) + snapshot.readByte();
   }

   _display.switchOff();
   _memory.resetBank();
   _keyboard.getKeyStat = getKeyStat;
}











//-----------------------

/*
   // Set whether to use a real timer to control the interrupt timing or
   // whether to just count the number of ticks to control the interrupts,
   // regardless of the real time. The latter is mostly used during debugging.
   public void useRealTime(boolean realTime){
      if(realTime && timer==null){
         timer = new Timer();
         TimerTask task = new TimerTask(){
            public void run() {
               scheduleOCIInterrupt();
            }
         };
         timer.scheduleAtFixedRate(task, 50, 50);
         TimerTask task2 = new TimerTask(){
            public void run() {
               scheduleNMIInterrupt();
            }
         };
         timer.scheduleAtFixedRate(task2, 1000, 1000);
      }else if( !realTime && timer!=null){
         timer.cancel();
         timer = null;
         _OCIdue = false;
         _ticksSinceNMI = 0;
      }
   }

}*/