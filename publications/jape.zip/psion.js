var requestAnimationFrame = (
   window.requestAnimationFrame || window.msRequestAnimationFrame ||
   window.mozRequestAnimationFrame || window.webkitRequestAnimationFrame ||
   window.oRequestAnimationFrame ||
   function(callback) {
      setTimeout(function() {
         callback();
      }, 17);
   }
);


function ImageBank(){
   var _bank = {};
   var _loading = 0;
   this.getImage = function(loc){
      var img = _bank[loc];
      if( !img ){
         img = new Image();
         _bank[loc] = img;
         _loading++;
         img.onload = function() { _loading--; };
         img.onerror = function() {
            alert("Unable to load image from url "+loc);
         };
         img.src = loc;
      }
      return img;
   }
   this.isReady = function(){ return _loading==0; }
}


var PsionModels = [
   { type: "CM (8k)", default:2, variant: [
      { name: "Rom 2.4",            rom:"roms/24-cm.rom",   ram:8,  screen:2, screenImage:"images/disp_2cm.gif",  keyboard: KeyboardLayout.Normal, keyboardImage:"images/keyb_norm.gif", coverImage:"images/cover_org2.gif"},
      { name: "Rom 2.6",            rom:"roms/26-cm.rom",   ram:8,  screen:2, screenImage:"images/disp_2cm.gif",  keyboard: KeyboardLayout.Normal, keyboardImage:"images/keyb_norm.gif", coverImage:"images/cover_org2.gif"},
      { name: "Rom 3.3",            rom:"roms/33-cm.rom",   ram:8,  screen:2, screenImage:"images/disp_2cm.gif",  keyboard: KeyboardLayout.Normal, keyboardImage:"images/keyb_norm.gif", coverImage:"images/cover_org2.gif"},
      { name: "Rom 3.3, French",    rom:"roms/33-cmf.rom",  ram:8,  screen:2, screenImage:"images/disp_2cm.gif",  keyboard: KeyboardLayout.Normal, keyboardImage:"images/keyb_norm.gif", coverImage:"images/cover_org2.gif"},
      { name: "Rom 3.6, French",    rom:"roms/36-cmf.rom",  ram:8,  screen:2, screenImage:"images/disp_2cm.gif",  keyboard: KeyboardLayout.Normal, keyboardImage:"images/keyb_norm.gif", coverImage:"images/cover_org2.gif"},
   ]},
   { type: "XP (16k)", default:2, variant: [
      { name: "Rom 2.4",            rom:"roms/24-xp.rom",   ram:16, screen:2, screenImage:"images/disp_2xp.gif",  keyboard: KeyboardLayout.Normal, keyboardImage:"images/keyb_norm.gif", coverImage:"images/cover_org2.gif"},
      { name: "Rom 2.6",            rom:"roms/26-xp.rom",   ram:16, screen:2, screenImage:"images/disp_2xp.gif",  keyboard: KeyboardLayout.Normal, keyboardImage:"images/keyb_norm.gif", coverImage:"images/cover_org2.gif"},
      { name: "Rom 3.1",            rom:"roms/31-xp.rom",   ram:16, screen:2, screenImage:"images/disp_2xp.gif",  keyboard: KeyboardLayout.Normal, keyboardImage:"images/keyb_norm.gif", coverImage:"images/cover_org2.gif"},
   ]},
   { type: "XP (32k)", default:3, variant: [
      { name: "Rom 3.0",            rom:"roms/33-lahp.rom", ram:32, screen:2, screenImage:"images/disp_2xp.gif",  keyboard: KeyboardLayout.Normal, keyboardImage:"images/keyb_norm.gif", coverImage:"images/cover_org2.gif"},
      { name: "Rom 3.3",            rom:"roms/33-la.rom",   ram:32, screen:2, screenImage:"images/disp_2xp.gif",  keyboard: KeyboardLayout.Normal, keyboardImage:"images/keyb_norm.gif", coverImage:"images/cover_org2.gif"},
      { name: "Rom 3.4, German",    rom:"roms/34-lag.rom",  ram:32, screen:2, screenImage:"images/disp_2xp.gif",  keyboard: KeyboardLayout.Normal, keyboardImage:"images/keyb_norm.gif", coverImage:"images/cover_org2.gif"},
      { name: "Rom 3.6",            rom:"roms/36-la.rom",   ram:32, screen:2, screenImage:"images/disp_2xp.gif",  keyboard: KeyboardLayout.Normal, keyboardImage:"images/keyb_norm.gif", coverImage:"images/cover_org2.gif"},
      { name: "Rom 3.6, French",    rom:"roms/36-laf.rom",  ram:32, screen:2, screenImage:"images/disp_2xp.gif",  keyboard: KeyboardLayout.Normal, keyboardImage:"images/keyb_norm.gif", coverImage:"images/cover_org2.gif"},
      { name: "Rom 3.6, German",    rom:"roms/36-lag.rom",  ram:32, screen:2, screenImage:"images/disp_2xp.gif",  keyboard: KeyboardLayout.Normal, keyboardImage:"images/keyb_norm.gif", coverImage:"images/cover_org2.gif"},
      { name: "Rom 3.7, Multilingual",rom:"roms/37-lam.rom",   ram:32, screen:2, screenImage:"images/disp_2xp.gif",  keyboard: KeyboardLayout.Normal, keyboardImage:"images/keyb_norm.gif", coverImage:"images/cover_org2.gif"},
   ]},
   { type: "LZ (32k)", default:5, variant: [
      { name: "Rom 4.2",            rom:"roms/42-lz.rom",   ram:32, screen:4, screenImage:"images/disp_4lz.gif",  keyboard: KeyboardLayout.Normal, keyboardImage:"images/keyb_norm.gif", coverImage:"images/cover_org2.gif"},
      { name: "Rom 4.4",            rom:"roms/44-lz.rom",   ram:32, screen:4, screenImage:"images/disp_4lz.gif",  keyboard: KeyboardLayout.Normal, keyboardImage:"images/keyb_norm.gif", coverImage:"images/cover_org2.gif"},
      { name: "Rom 4.5",            rom:"roms/45-lz.rom",   ram:32, screen:4, screenImage:"images/disp_4lz.gif",  keyboard: KeyboardLayout.Normal, keyboardImage:"images/keyb_norm.gif", coverImage:"images/cover_org2.gif"},
      { name: "Rom 4.5, Italian/Spanish",rom:"roms/45-lzi.rom",   ram:32, screen:4, screenImage:"images/disp_4lz.gif",  keyboard: KeyboardLayout.Normal, keyboardImage:"images/keyb_norm.gif", coverImage:"images/cover_org2.gif"},
      { name: "Rom 4.5, Swedish/Danish",rom:"roms/45-lzs.rom", ram:32, screen:4, screenImage:"images/disp_4lz.gif",  keyboard: KeyboardLayout.Normal, keyboardImage:"images/keyb_norm.gif", coverImage:"images/cover_org2.gif"},
      { name: "Rom 4.6",            rom:"roms/46-lz.rom",   ram:32, screen:4, screenImage:"images/disp_4lz.gif",  keyboard: KeyboardLayout.Normal, keyboardImage:"images/keyb_norm.gif", coverImage:"images/cover_org2.gif"},
      { name: "Rom 4.6, Italian/Spanish",rom:"roms/46-lzi.rom",   ram:32, screen:4, screenImage:"images/disp_4lz.gif",  keyboard: KeyboardLayout.Normal, keyboardImage:"images/keyb_norm.gif", coverImage:"images/cover_org2.gif"},
   ]},
   { type: "LZ64 (64k)", default:3, variant: [
      { name: "Rom 4.3",            rom:"roms/43-lz64.rom", ram:64, screen:4, screenImage:"images/disp_4lz64.gif",   keyboard: KeyboardLayout.Normal, keyboardImage:"images/keyb_norm.gif", coverImage:"images/cover_org2.gif"},
      { name: "Rom 4.4",            rom:"roms/44-lz64.rom", ram:64, screen:4, screenImage:"images/disp_4lz64.gif",   keyboard: KeyboardLayout.Normal, keyboardImage:"images/keyb_norm.gif", coverImage:"images/cover_org2.gif"},
      { name: "Rom 4.5",            rom:"roms/45-lz64.rom", ram:64, screen:4, screenImage:"images/disp_4lz64.gif",   keyboard: KeyboardLayout.Normal, keyboardImage:"images/keyb_norm.gif", coverImage:"images/cover_org2.gif"},
      { name: "Rom 4.6a",           rom:"roms/46a-lz64.rom", ram:64, screen:4, screenImage:"images/disp_4lz64.gif",  keyboard: KeyboardLayout.Normal, keyboardImage:"images/keyb_norm.gif", coverImage:"images/cover_org2.gif"},
      { name: "Rom 4.6b",           rom:"roms/46b-lz64.rom", ram:64, screen:4, screenImage:"images/disp_4lz64.gif",  keyboard: KeyboardLayout.Normal, keyboardImage:"images/keyb_norm.gif", coverImage:"images/cover_org2.gif"},
      { name: "Rom 4.6, Italian/Spanish",rom:"roms/46-lz64i.rom",ram:64, screen:4, screenImage:"images/disp_4lz64.gif", keyboard: KeyboardLayout.Normal, keyboardImage:"images/keyb_norm.gif", coverImage:"images/cover_org2.gif"},
      { name: "Rom 4.6, Swedish/Danish",rom:"roms/46-lz64s.rom",ram:64, screen:4, screenImage:"images/disp_4lz64.gif",  keyboard: KeyboardLayout.Normal, keyboardImage:"images/keyb_norm.gif", coverImage:"images/cover_org2.gif"},
   ]},
   { type: "POS (CM/XP)", default:0, variant: [
      { name: "Pos 200, Rom 3.6",   rom:"roms/36-p200.rom", ram:32, screen:2, screenImage:"images/disp_2xp.gif",  keyboard: KeyboardLayout.Pos200, keyboardImage:"images/keyb_pos.gif" , coverImage:"images/cover_org2.gif"},
      { name: "Alpha Pos, Rom 3.3", rom:"roms/33-p200a.rom",ram:32, screen:2, screenImage:"images/disp_2xp.gif",  keyboard: KeyboardLayout.AlphaPos, keyboardImage:"images/keyb_posa.gif", coverImage:"images/cover_org2.gif"},
      { name: "Alpha Pos, Rom 3.6", rom:"roms/36-p200a.rom",ram:32, screen:2, screenImage:"images/disp_2xp.gif",  keyboard: KeyboardLayout.AlphaPos, keyboardImage:"images/keyb_posa.gif", coverImage:"images/cover_org2.gif"},
      { name: "Pos 250, Rom 3.6",   rom:"roms/36-p250.rom", ram:32, screen:2, screenImage:"images/disp_2p250.gif",   keyboard: KeyboardLayout.Normal, keyboardImage:"images/keyb_norm.gif", coverImage:"images/cover_org2.gif"},
      { name: "Pos 350, Rom 3.6",   rom:"roms/36-p350.rom", ram:96, screen:2, screenImage:"images/disp_2p350.gif",   keyboard: KeyboardLayout.Normal, keyboardImage:"images/keyb_norm.gif", coverImage:"images/cover_org2.gif"},
      { name: "Pos 350, Rom 3.8",   rom:"roms/38-p350.rom", ram:96, screen:2, screenImage:"images/disp_2p350.gif",   keyboard: KeyboardLayout.Normal, keyboardImage:"images/keyb_norm.gif", coverImage:"images/cover_org2.gif"},
   ]},
   { type: "POS (LZ/LZ64)", default:0, variant: [
      { name: "P432, POS200, Rom 4.6", rom:"roms/46-p432n.rom", ram:32, screen:4, screenImage:"images/disp_4p432.gif",   keyboard: KeyboardLayout.Pos200, keyboardImage:"images/keyb_pos.gif", coverImage:"images/cover_org2.gif"},
      { name: "P464, Rom 4.6",      rom:"roms/46-p464.rom", ram:64, screen:4, screenImage:"images/disp_4p464.gif",   keyboard: KeyboardLayout.Normal, keyboardImage:"images/keyb_norm.gif", coverImage:"images/cover_org2.gif"},
   ]},
];

function Psion(cv){
   if (typeof(cv) === 'string') {
      cv = document.getElementById(cv);
   }

   var _canvas  = cv;
   var _context = cv.getContext("2d");
   var _hd6303;
   var _memory;
   var _display;
   var _keyboard;
   var _bus;
   var _isReady = false;
   var _isRunning = false;
   var _frequency = 921600;
   var _firstFrameTime = -1;
   var _ticksPerformed = -1;
   var _executionTime;
   var _framecount;
   var _animationframe;
   var _imagebank = new ImageBank();
   var _keyboardImage;
   var _screenImage;
   var _coverImage;
   var _contrastUpImage = _imagebank.getImage( "images/contrastup.gif" );
   var _contrastDnImage = _imagebank.getImage( "images/contrastdn.gif" );
   var _onSwitchOnOff = function(){};

   this.reset = function(model){
      _display = new Display(_context, model.screen);
      if( !model.romfile ) model.romfile = new BinaryFile(model.rom, false);
      _memory = new Memory(model.ram, model.romfile);
      _keyboard = new Keyboard(model.keyboard);
      var pks = _bus ? _bus.getPacks() : undefined;
      var sc = _bus ? _bus.setClockAtNMI : false;
      var ccb = _bus ? _bus.clockCallback : false;
      _bus = new Bus(_memory,_display,_keyboard);
      if( pks ){
         for( var i=0; i<3; i++) _bus.setPack(pks[i],i);
         _bus.setClockAtNMI = sc;
         _bus.clockCallback = ccb;
      }
      _hd6303 = new HD6303(_bus);
      _keyboardImage = _imagebank.getImage( model.keyboardImage );
      _screenImage = _imagebank.getImage( model.screenImage );
      _coverImage = _imagebank.getImage( model.coverImage );
      _needRefresh = true;
      _isReady = false;

      _bus.onSwitchOnOff = function(state){
         _hd6303.onSwitchOnOff();
         _needRefresh = true;
         _onSwitchOnOff(state);
      }
   }

   this.setOnSwitchOnOff = function(fnc){
      _onSwitchOnOff = fnc;
   }
   this.setClockCallback = function(fnc){
      _bus.clockCallback = fnc;
   }


   this.handleKeyUp      = function(ke){ if(_keyboard)_keyboard.handleKeyUp(ke); }
   this.handleKeyDown     = function(ke){ if(_keyboard)_keyboard.handleKeyDown(ke); }
   this.clear            = function(  ){ if(_keyboard)_keyboard.clear(); }
   this.handleMouseDown = function(me){ handleMouseEvent(me,0); }
   this.handleMouseUp     = function(me){ handleMouseEvent(me,1); }
   this.handleMouseMove = function(me){ handleMouseEvent(me,2); }
   this.handleTouchDown = function(te){ handleTouchEvent(te,0); }
   this.handleTouchUp     = function(te){ handleTouchEvent(te,1); }
   this.handleTouchMove = function(te){ handleTouchEvent(te,2); }
   this.handleTouchCancel = function(te){ handleTouchEvent(te,3); }

   function handleMouseEvent(me,type){
      if(me.preventDefault) me.preventDefault();
      if(me.stopPropagation) me.stopPropagation();
      handleTouch("mouse", me.clientX, me.clientY, type);
   }
   function handleTouchEvent(te,type){
      if(te.preventDefault) te.preventDefault();
      if(te.stopPropagation) te.stopPropagation();
      var touches = te.changedTouches;
      for (var i = 0; i < touches.length; i++) {
         var t = touches[i];
         handleTouch(t.identifier, t.clientX, t.clientY, type);
      }
   }
   function handleTouch( id, x, y, type){
       var rect = _canvas.getBoundingClientRect();
       x -= rect.left;
       y -= rect.top;
      if   ( type==0 ) handleDown(id,x,y);
      else if( type==1 ) handleUp(id,x,y);
      else if( type==2 ) handleMove(id,x,y);
      else if( type==3 ) handleUp(id,x,y);
   }

   var ongoingTouches = new Array();

   function ongoingTouchIndexById(idToFind) {
     for (var i = 0; i < ongoingTouches.length; i++) {
       var id = ongoingTouches[i].id;
       if (id == idToFind) {
         return i;
       }
     }
     return -1;    // not found
   }

   var _keyboardX = 5+19;
   var _keyboardY = 152+19;
   var _keyX = 45;
   var _keyY = 45;
   var _contrastWidth = 17;
   var _contrastHeight = 19;
   var _contrastX = 5+309+2;
   var _contrastUpY = 152+2;
   var _contrastDnY = _contrastUpY+_contrastHeight+2;
   function getItemFromCoords(x,y){
      if(!_isRunning) return null;
      var r = Math.floor((y-_keyboardY)/_keyY);
      var c = Math.floor((x-_keyboardX)/_keyX);
      if(_coverY==_coverDownY && x>=0 && y>=_coverDownY && x<309 && y<_coverDownY+439){
         _coverMoveStartTime = Date.now();
         _coverMoveDirection = -1;
      }
      else if(_coverY==_coverUpY && x>=0 && y>=_coverUpY && x<309 && y<_coverUpY+439){
         _coverMoveStartTime = Date.now();
         _coverMoveDirection = 1;
      }
      else if( r>=0 && r<6 && c>=0 && c<6){
         return {type:"key", row:r, column:c,
            minx:_keyboardX+_keyX*c, maxx:_keyboardX+_keyX*(c+1),
            miny:_keyboardY+_keyY*r, maxy:_keyboardY+_keyY*(r+1)
         };
      }
      else if(x>=_contrastX && y>=_contrastUpY && x<_contrastX+_contrastWidth && y<_contrastUpY+_contrastHeight){
         if( _coverY==_coverDownY )
            _display.increaseContrast();
      }
      else if(x>=_contrastX && y>=_contrastDnY && x<_contrastX+_contrastWidth && y<_contrastDnY+_contrastHeight){
         if( _coverY==_coverDownY )
            _display.decreaseContrast();
      }
      return null;
   }

   function handleDown( id, x, y){
      // remove any old out of date data
      var ix = ongoingTouchIndexById(id);
      if( ix>=0 ) ongoingTouches.splice(ix,1);
      var item = getItemFromCoords(x,y);
      // store in array
      if( item ){
         ongoingTouches.push({id:id, item:item});
         if(_keyboard)_keyboard.handleItemPress(item,true,id=="mouse");
      }
   }
   function handleUp( id, x, y){
      // find stored data for this touch
      var ix = ongoingTouchIndexById(id);
      if(ix>=0 ) {  // nothing to do if not found
         var item = ongoingTouches[ix].item;
         ongoingTouches.splice(ix,1);
         if(_keyboard)_keyboard.handleItemPress(item,false,id=="mouse");
      }
   }
   function handleMove( id, x, y){
      // find stored data for this touch
      var ix = ongoingTouchIndexById(id);
      if(ix>=0 ) {  // nothing to do if not found
         // check if we are still in the bounds of the original item
         var item = ongoingTouches[ix].item;
         if( x<item.minx || x>item.maxx || y<item.miny || y>item.maxy ){
            // moved out of bounds. Act same as if released.
            ongoingTouches.splice(ix,1);
            if(_keyboard)_keyboard.handleItemPress(item,false,id=="mouse");
         }
      }
   }

   this.setPack = function(pack, slot) {
      _bus.setPack(pack,slot);
      _isReady = false;
   }

   var _coverUpY = 152;
   var _coverDownY = _coverUpY+319;
   var _coverY = _coverUpY;
   var _coverMoveStartTime;
   var _coverMoveDirection = 0; // +1=moving down, -1=moving up, 0=nomove
   var _coverTime = 500;   // total time to move ccver

   function updateCoverPos(){
      if( !_coverMoveDirection ) return false;
      var t = (Date.now()-_coverMoveStartTime)/_coverTime;
      if( t>=1 ){
         if( _coverMoveDirection>0 ){
            _coverY = _coverDownY;
            _keyboard.enable();
         }else{
            _coverY = _coverUpY;
            _keyboard.disable();
         }
         _coverMoveDirection = 0;
      }else{
         var dist = t*t*(_coverDownY-_coverUpY);
         _coverY = _coverMoveDirection>0 ? _coverUpY+dist : _coverDownY-dist;
      }
      return true;
   }

   function doFrame(t){
      if( !_isRunning ) return;
      var startTime = Date.now();
      if(!t) t = startTime;
      if( _firstFrameTime<0 ){
         _firstFrameTime = t;
         _ticksPerformed = 0;
         _executionTime = 0;
         _framecount = 0;
      }else{
         if( !_isReady ){
            // check if have become ready
            if( _imagebank.isReady() && _bus.isReady() && FlashDriver.isReady()){
               _isReady = true;
            }
         }
         if( _isReady ){
            // calculate how many ticks to execute
            var ticksToExecute = (t - _firstFrameTime)*_frequency/1000 - _ticksPerformed;
            if( ticksToExecute>_frequency*0.5 ){
               console.log("resetting timing");
               _firstFrameTime = -1;
               requestAnimationFrame(doFrame);
               return;
            }
            _hd6303.execute(ticksToExecute);
            _ticksPerformed += ticksToExecute;
            _needRefresh |= updateCoverPos();
            if(_needRefresh){
               _context.fillStyle = "white";
               _context.fillRect(0,0,_canvas.width,_canvas.height);
               _context.drawImage(_screenImage, 0, 0);
               _context.drawImage(_keyboardImage, 5, 152);
               _context.drawImage(_coverImage, 0, _coverY);
               if( _coverY==_coverDownY && !_bus.isSwitchedOff() ){
                  _context.drawImage(_contrastUpImage, _contrastX, _contrastUpY);
                  _context.drawImage(_contrastDnImage, _contrastX, _contrastDnY);
               }
            }
            _display.refresh(_needRefresh);
            _needRefresh = false;
         }
      }
      var endTime = Date.now();
      _executionTime += endTime - startTime;
      _framecount++;
      if( _framecount%300==0 ){
         console.log("frame speed:"+((t - _firstFrameTime)/_framecount)+"  execution load:"+100*_executionTime/(t - _firstFrameTime)+"%");
      }

      if(_isRunning) _animationframe = requestAnimationFrame(doFrame);
   }

   this.startRunning = function(){
      if( !_isRunning ){
         _isRunning = true;
         _isReady = false;
         _firstFrameTime = -1;
         requestAnimationFrame(doFrame);
      }
   }

   this.stopRunning = function(){
      if( _isRunning ){
         _isRunning = false;
         window.cancelAnimationFrame(_animationframe);
         _isReady = false;
         _firstFrameTime = -1;
      }
   }
   this.isRunning = function(){
      return _isRunning;
   }

   this.createSnapshot = function(){
      if( !_isReady ) return null;
      var arr = [1, _memory.read(0xffe8), _memory.read(0xffe7)];
      _hd6303.getSnapshotData(arr);
      _bus.getSnapshotData(arr);
      _display.getSnapshotData(arr);
      _memory.getSnapshotData(arr);
      return new Snapshot({data: arr});
   }
   this.applySnapshotData = function(snapshot){
      if( !_isReady ) return;
      snapshot.reset();
      if( snapshot.readByte()>1 ){
         alert("Snapshot is incompatible with this emulator (corrupt or of a later version).");
         return;
      }
      var model1 = snapshot.readByte();
      if( model1!=_memory.read(0xffe8) ){
         var s = model1==0 ? "CM" :
                  model1==1 ? "XP(16K)" :
                  model1==2 ? "XP(32K)" :
                  model1==14 ? "LZ" :
                  model1==13 ? "LZ64" :
                  "Modelbyte="+model1;
         alert("Snapshot ["+s+"] is incompatible with this model of Psion II.");
         return;
      }
      var model2 = snapshot.readByte();
      if( (model2&0x80)!=(_memory.read(0xffe7)&0x80) ){
         var s = model2&0x80 ? "multilingual" : "monolingual";
         alert("Snapshot is for a "+s+" version of the Psion II.");
         return;
      }
      _hd6303.applySnapshotData(snapshot);
      _bus.applySnapshotData(snapshot);
      _display.applySnapshotData(snapshot);
      _memory.applySnapshotData(snapshot);
      if( !snapshot.atEnd ){
        alert("Snapshot contains superfluous data!");
     }
   }

   this.setClock = function(){
      _bus.setClockAtNMI = true;
   }
}

