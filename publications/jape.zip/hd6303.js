'use strict';

/**
 * emulates the HD6303 microprocessor.
 */


function HD6303(bus){
   var _bus = bus;
   var _sleep=true;

   var F_C  = 0x01;
   var F_V  = 0x02;
   var F_Z  = 0x04;
   var F_N  = 0x08;
   var F_I  = 0x10;
   var F_H  = 0x20;

   /** Main registers */
   var _A = 0;
   var _B = 0;
   var _X = 0;
   var fH = false, fI = false, fN = false;
   var fZ = false, fC = false, fV = false;

   /** Stack Pointer and Program Counter */
   var _SP = 0, _PC = 0;

   /** 8 bit register access */
   function A() { return _A; }
   function setA( bite ) { _A = bite&0xff; }
   function B() { return _B; }
   function setB( bite ) { _B = bite&0xff; }

   /** 16 bit register access */
   function D(){ return (_A<<8) + _B; }
   function setD( word ) {
      setA(word>>8);
      setB(word);
   }

   function X() { return _X; }
   function setX( word ) { _X = word&0xffff; }

   function PC() { return _PC; }
   function setPC( word ) { _PC = word&0xffff; }

   function SP() { return _SP; }
   function setSP( word ) { _SP = word&0xffff; }

   /** Flag access */
   function setH( f ) { fH = f; }
   function setI( f ) { fI = f; }
   function setN( f ) { fN = f; }
   function setZ( f ) { fZ = f; }
   function setV( f ) { fV = f; }
   function setC( f ) { fC = f; }
   function Hset() { return fH; }
   function Iset() { return fI; }
   function Nset() { return fN; }
   function Zset() { return fZ; }
   function Vset() { return fV; }
   function Cset() { return fC; }

   function P() {
      return (
         (Hset() ? F_H : 0) |
         (Iset() ? F_I : 0) |
         (Nset() ? F_N : 0) |
         (Zset() ? F_Z : 0) |
         (Cset() ? F_C : 0) |
         (Vset() ? F_V : 0) |
         0xc0 );
   }
   function setP( bite ) {
      setH( (bite & F_H) != 0 );
      setI( (bite & F_I) != 0 );
      setN( (bite & F_N) != 0 );
      setZ( (bite & F_Z) != 0 );
      setC( (bite & F_C) != 0 );
      setV( (bite & F_V) != 0 );
   }

   /** Byte access */
   function peekb( addr ) {
      return _bus.read(addr & 0xffff) & 0xff;
   }
   function pokeb( addr, newByte ) {
      _bus.write(addr & 0xffff, newByte&0xff);
   }

   /** Word access */
   function pokew( addr, word ) {
      pokeb( addr, word >> 8 );
      pokeb( addr+1, word );
   }
   function peekw( addr ) {
      var t = peekb( addr )<<8;
      t += peekb( addr+1 );
      return t;
   }

   /** Stack access */
   function pushw( word ) {
      setSP( SP()-2 );
      pokew( SP(), word );
   }
   function popw() {
      var t  = peekw( SP() );
      setSP( SP()+2 );
      return t;
   }
   function pushb( b ) {
      setSP( SP()-1 );
      pokeb( SP(), b );
   }
   function popb() {
      var t  = peekb( SP() );
      setSP( SP()+1 );
      return t;
   }

   /** Program access */
   function nxtpcb() {
      var t = peekb( PC() );
      setPC( PC()+1 );
      return t;
   }
   function nxtpcw() {
      var t = peekw( PC() );
      setPC( PC()+2 );
      return t;
   }

   /** Reset all registers to power on state */
   function resetForBoot() {
      setPC(peekw(0xfffe));
      setSP(0);
      setD(0);
      setX(0);
      setP(255);
      _sleep=false;
      console.log("resetting hd6303");
   }

   this.onSwitchOnOff = function(){
      if(_bus.isSwitchedOff()){
         _sleep = true;
      }else{
         resetForBoot();
      }
   }

   /** Interrupt handlers */
   function dointerrupt(m) {
      pushw(PC());
      pushw(X());
      pushb(A());
      pushb(B());
      pushb(P());
      setI(true);
      setPC(peekw(m));
      return 11;
   }


   /** HD6303 fetch/execute loop */
   this.execute = function(ticksToExecute) {
      while ( ticksToExecute>0 ) {

         var ticks=0;
         //check for NMI
         if ( _bus.isNMIdue() ) {
            // do NMI
            ticks+=dointerrupt(0xfffc);
            _sleep=false;
         }
         // check for OCI
         if( _bus.isOCIdue() && !Iset() ){
            // do OCI
            ticks += dointerrupt(0xfff4);
            _sleep=false;
         }

         if( (SP()>0 && SP()<0x00e0) || (SP()>=0x100 && SP()<0x400) || SP()>0x8000 ){
            console.log("Stack error!  SP="+SP());
            break;
         }

         var inst = _sleep || _bus.isSwitchedOff() ? 1 : nxtpcb();
         ticks++;
         switch ( inst ) {

         case 0:  /* TRAP */
         {
            ticks+=dointerrupt(0xffee); break;
         }
         case 1:  /* NOP */
         { break; }
         case 4:  /* LSRD */
         { setD(lsr(D())); break; }
         case 5:  /* ASLD */
         { setD(asl16(D())); break; }
         case 6:  /* TAP */
         { setP(A()); break; }
         case 7:  /* TPA */
         { setA(P()); break; }
         case 8:  /* INX */
         { setX(X()+1); setZ(X()==0); break; }
         case 9:  /* DEX */
         { setX(X()-1); setZ(X()==0); break; }
         case 10: /* CLV */
         { setV(false); break; }
         case 11: /* SEV */
         { setV(true); break; }
         case 12: /* CLC */
         { setC(false); break; }
         case 13: /* SEC */
         { setC(true); break; }
         case 14: /* CLI */
         { setI(false); break; }
         case 15: /* SEI */
         { setI(true); break; }

         case 16: /* SBA */
         { setA(sub8(A(),B())); break; }
         case 17: /* CBA */
         { sub8(A(),B()); break; }

         case 22: /* TAB */
         { setB(ld8(A())); break; }
         case 23: /* TBA */
         { setA(ld8(B())); break; }
         case 24: /* XGDX */
         { var x=X();setX(D());setD(x);ticks++; break; }
         case 25: /* DAA */
         { daa();ticks++; break; }
         case 26: /* SLP */
         { ticks+=3; _sleep=true; break; }
         case 27: /* ABA */
         { setA(add8(A(),B())); break; }


         case 32: /* BRA dis */
         {
            var d = nxtpcb();
            if(d>=0x80) d-=0x100;
            setPC( PC()+d );
            ticks += 2;
            break;
         }
         case 33: /* BRN dis */
         {
            nxtpcb();
            ticks += 2;
            break;
         }
         case 34: /* BHI dis */
         {
            var d = nxtpcb();
            if( !Cset() && !Zset() ){
               if(d>=0x80) d-=0x100;
               setPC( PC()+d );
            }
            ticks += 2;
            break;
         }
         case 35: /* BLS dis */
         {
            var d = nxtpcb();
            if( Cset() || Zset() ){
               if(d>=0x80) d-=0x100;
               setPC( PC()+d );
            }
            ticks += 2;
            break;
         }
         case 36: /* BCC dis */
         {
            var d = nxtpcb();
            if( !Cset() ){
               if(d>=0x80) d-=0x100;
               setPC( PC()+d );
            }
            ticks += 2;
            break;
         }
         case 37: /* BCS dis */
         {
            var d = nxtpcb();
            if( Cset() ){
               if(d>=0x80) d-=0x100;
               setPC( PC()+d );
            }
            ticks += 2;
            break;
         }
         case 38: /* BNE dis */
         {
            var d = nxtpcb();
            if( !Zset() ){
               if(d>=0x80) d-=0x100;
               setPC( PC()+d );
            }
            ticks += 2;
            break;
         }
         case 39: /* BEQ dis */
         {
            var d = nxtpcb();
            if( Zset() ){
               if(d>=0x80) d-=0x100;
               setPC( PC()+d );
            }
            ticks += 2;
            break;
         }
         case 40: /* BVC dis */
         {
            var d = nxtpcb();
            if( !Vset() ){
               if(d>=0x80) d-=0x100;
               setPC( PC()+d );
            }
            ticks += 2;
            break;
         }
         case 41: /* BVS dis */
         {
            var d = nxtpcb();
            if( Vset() ){
               if(d>=0x80) d-=0x100;
               setPC( PC()+d);
            }
            ticks += 2;
            break;
         }
         case 42: /* BPL dis */
         {
            var d = nxtpcb();
            if( !Nset() ){
               if(d>=0x80) d-=0x100;
               setPC( PC()+d);
            }
            ticks += 2;
            break;
         }
         case 43: /* BMI dis */
         {
            var d = nxtpcb();
            if( Nset() ){
               if(d>=0x80) d-=0x100;
               setPC( PC()+d );
            }
            ticks += 2;
            break;
         }
         case 44: /* BGE dis */
         {
            var d = nxtpcb();
            if( Nset()==Vset() ){
               if(d>=0x80) d-=0x100;
               setPC( PC()+d);
            }
            ticks += 2;
            break;
         }
         case 45: /* BLT dis */
         {
            var d = nxtpcb();
            if( Nset()!=Vset() ){
               if(d>=0x80) d-=0x100;
               setPC( PC()+d );
            }
            ticks += 2;
            break;
         }
         case 46: /* BGT dis */
         {
            var d = nxtpcb();
            if( Nset()==Vset() && !Zset() ){
               if(d>=0x80) d-=0x100;
               setPC( PC()+d );
            }
            ticks += 2;
            break;
         }
         case 47: /* BLE dis */
         {
            var d = nxtpcb();
            if( Nset()!=Vset() || Zset() ){
               if(d>=0x80) d-=0x100;
               setPC(PC()+d);
            }
            ticks += 2;
            break;
         }

         case 48: /* TSX */
         { setX(SP()); break; }
         case 49: /* INS */
         { setSP(SP()+1); break; }
         case 50: /* PULA */
         { setA( popb() ); ticks+=2; break; }
         case 51: /* PULB */
         { setB( popb() ); ticks+=2; break; }
         case 52: /* DES */
         { setSP(SP()-1); break; }
         case 53: /* TXS */
         { setSP(X()); break; }
         case 54: /* PSHA */
         { pushb(A()); ticks+=3; break; }
         case 55: /* PSHB */
         { pushb(B()); ticks+=3; break; }
         case 56: /* PULX */
         { setX( popw() ); ticks+=3; break; }
         case 57: /* RTS */
         {
            setPC( popw() );ticks+=4; break;
         }
         case 58: /* ABX */
         { setX(X()+B()); break; }
         case 59: /* RTI */
         {
            setP( popb() );
            setB( popb() );
            setA( popb() );
            setX( popw() );
            setPC( popw() );
            ticks+=9;
            break;
         }
         case 60: /* PSHX */
         { pushw(X()); ticks+=4; break; }
         case 61: /* MUL */
         { setD(A()*B()); setC((B()&0x80)!=0); ticks+=6; break; }
         case 62: /* WAI */
         { ticks+=8; break; }
         case 63: /* SWI */
         {
            ticks+=dointerrupt(0xfffa); break;
         }

         case 64: /* NEGA */
         { setA(neg8(A())); break; }
         case 67: /* COMA */
         { setA(com8(A())); break; }
         case 68: /* LSRA */
         { setA(lsr(A())); break; }
         case 70: /* RORA */
         { setA(ror8(A())); break; }
         case 71: /* ASRA */
         { setA(asr8(A())); break; }
         case 72: /* ASLA */
         { setA(asl8(A())); break; }
         case 73: /* ROLA */
         { setA(rol8(A())); break; }
         case 74: /* DECA */
         { setA(dec8(A())); break; }
         case 76: /* INCA */
         { setA(inc8(A())); break; }
         case 77: /* TSTA */
         { tst8(A()); break; }
         case 79: /* CLRA */
         { setA(clr8()); break; }

         case 80: /* NEGB */
         { setB(neg8(B())); break; }
         case 83: /* COMB */
         { setB(com8(B())); break; }
         case 84: /* LSRB */
         { setB(lsr(B())); break; }
         case 86: /* RORB */
         { setB(ror8(B())); break; }
         case 87: /* ASRB */
         { setB(asr8(B())); break; }
         case 88: /* ASLB */
         { setB(asl8(B())); break; }
         case 89: /* ROLB */
         { setB(rol8(B())); break; }
         case 90: /* DECB */
         { setB(dec8(B())); break; }
         case 92: /* INCB */
         { setB(inc8(B())); break; }
         case 93: /* TSTB */
         { tst8(B()); break; }
         case 95: /* CLRB */
         { setB(clr8()); break; }

         case 96: /* NEG d,X */
         { var m=X()+nxtpcb(); pokeb(m,neg8(peekb(m))); ticks+=5; break; }
         case 97: /* AIM #,d,X */
         { var b=nxtpcb(); var m=X()+nxtpcb(); pokeb(m,and8(b,peekb(m))); ticks+=6; break; }
         case 98: /* OIM #,d,X */
         { var b=nxtpcb(); var m=X()+nxtpcb(); pokeb(m,or8(b,peekb(m))); ticks+=6; break; }
         case 99: /* COM d,X */
         { var m=X()+nxtpcb(); pokeb(m,com8(peekb(m))); ticks+=5; break; }
         case 100:   /* LSR d,X */
         { var m=X()+nxtpcb(); pokeb(m,lsr(peekb(m))); ticks+=5; break; }
         case 101:   /* EIM #,d,X */
         { var b=nxtpcb(); var m=X()+nxtpcb(); pokeb(m,eor8(b,peekb(m))); ticks+=6; break; }
         case 102:   /* ROR d,X */
         { var m=X()+nxtpcb(); pokeb(m,ror8(peekb(m))); ticks+=5; break; }
         case 103:   /* ASR d,X */
         { var m=X()+nxtpcb(); pokeb(m,asr8(peekb(m))); ticks+=5; break; }
         case 104:   /* ASL d,X */
         { var m=X()+nxtpcb(); pokeb(m,asl8(peekb(m))); ticks+=5; break; }
         case 105:   /* ROL d,X */
         { var m=X()+nxtpcb(); pokeb(m,rol8(peekb(m))); ticks+=5; break; }
         case 106:   /* DEC d,X */
         { var m=X()+nxtpcb(); pokeb(m,dec8(peekb(m))); ticks+=5; break; }
         case 107:   /* TIM #,d,X */
         { var b=nxtpcb(); var m=X()+nxtpcb(); and8(b,peekb(m)); ticks+=4; break; }
         case 108:   /* INC d,X */
         { var m=X()+nxtpcb(); pokeb(m,inc8(peekb(m))); ticks+=5; break; }
         case 109:   /* TST d,X */
         { var m=X()+nxtpcb(); tst8(peekb(m)); ticks+=3; break; }
         case 110:   /* JMP d,X */
         { var m=X()+nxtpcb(); setPC(m); ticks+=2; break; }
         case 111:   /* CLR d,X */
         { var m=X()+nxtpcb(); pokeb(m,clr8()); ticks+=4; break; }


         case 112:   /* NEG mm */
         { var m=nxtpcw(); pokeb(m,neg8(peekb(m))); ticks+=5; break; }
         case 113:   /* AIM #,0m */
         { var b=nxtpcb(); var m=nxtpcb(); pokeb(m,and8(b,peekb(m))); ticks+=5; break; }
         case 114:   /* OIM #,0m */
         { var b=nxtpcb(); var m=nxtpcb(); pokeb(m,or8(b,peekb(m))); ticks+=5; break; }
         case 115:   /* COM mm */
         { var m=nxtpcw(); pokeb(m,com8(peekb(m))); ticks+=5; break; }
         case 116:   /* LSR mm */
         { var m=nxtpcw(); pokeb(m,lsr(peekb(m))); ticks+=5; break; }
         case 117:   /* EIM #,0m */
         { var b=nxtpcb(); var m=nxtpcb(); pokeb(m,eor8(b,peekb(m))); ticks+=5; break; }
         case 118:   /* ROR mm */
         { var m=nxtpcw(); pokeb(m,ror8(peekb(m))); ticks+=5; break; }
         case 119:   /* ASR mm */
         { var m=nxtpcw(); pokeb(m,asr8(peekb(m))); ticks+=5; break; }
         case 120:   /* ASL mm */
         { var m=nxtpcw(); pokeb(m,asl8(peekb(m))); ticks+=5; break; }
         case 121:   /* ROL mm */
         { var m=nxtpcw(); pokeb(m,rol8(peekb(m))); ticks+=5; break; }
         case 122:   /* DEC mm */
         { var m=nxtpcw(); pokeb(m,dec8(peekb(m))); ticks+=5; break; }
         case 123:   /* TIM #,0m */
         { var b=nxtpcb(); var m=nxtpcb(); and8(b,peekb(m)); ticks+=3; break; }
         case 124:   /* INC mm */
         { var m=nxtpcw(); pokeb(m,inc8(peekb(m))); ticks+=5; break; }
         case 125:   /* TST mm */
         { var m=nxtpcw(); tst8(peekb(m)); ticks+=3; break; }
         case 126:   /* JMP mm */
         { var m=nxtpcw(); setPC(m); ticks+=2; break; }
         case 127:   /* CLR mm */
         { var m=nxtpcw(); pokeb(m,clr8()); ticks+=4; break; }

         case 128:   /* SUBA # */
         { var m=nxtpcb(); setA(sub8(A(),m)); ticks++; break; }
         case 129:   /* CMPA # */
         { var m=nxtpcb(); sub8(A(),m); ticks++; break; }
         case 130:   /* SBCA # */
         { var m=nxtpcb(); setA(sbc8(A(),m)); ticks++; break; }
         case 131:   /* SUBD ## */
         { var m=nxtpcw(); setD(sub16(D(),m)); ticks+=2; break; }
         case 132:   /* ANDA # */
         { var m=nxtpcb(); setA(and8(A(),m)); ticks++; break; }
         case 133:   /* BITA # */
         { var m=nxtpcb(); and8(A(),m); ticks++; break; }
         case 134:   /* LDAA # */
         { var m=nxtpcb(); setA(ld8(m)); ticks++; break; }
         case 136:   /* EORA # */
         { var m=nxtpcb(); setA(eor8(A(),m)); ticks++; break; }
         case 137:   /* ADCA # */
         { var m=nxtpcb(); setA(adc8(A(),m)); ticks++; break; }
         case 138:   /* ORAA # */
         { var m=nxtpcb(); setA(or8(A(),m)); ticks++; break; }
         case 139:   /* ADDA # */
         { var m=nxtpcb();setA(add8(A(),m)); ticks++; break; }
         case 140:   /* CPX ## */
         { var m=nxtpcw(); sub16(X(),m); ticks+=2; break; }
         case 141:   /* BSR d */
         {
            var d = nxtpcb();
            pushw(PC());
            if(d>=0x80) d-=0x100;
            setPC(PC()+d );
            ticks+=4; break;
         }
         case 142:   /* LDS ## */
         { var m=nxtpcw(); setSP(ld16(m)); ticks+=2; break; }

         case 144:   /* SUBA 0m */
         { var m=peekb(nxtpcb()); setA(sub8(A(),m)); ticks+=2; break; }
         case 145:   /* CMPA 0m */
         { var m=peekb(nxtpcb()); sub8(A(),m); ticks+=2; break; }
         case 146:   /* SBCA 0m */
         { var m=peekb(nxtpcb()); setA(sbc8(A(),m)); ticks+=2; break; }
         case 147:   /* SUBD 0m */
         { var m=peekw(nxtpcb()); setD(sub16(D(),m)); ticks+=3; break; }
         case 148:   /* ANDA 0m */
         { var m=peekb(nxtpcb()); setA(and8(A(),m)); ticks+=2; break; }
         case 149:   /* BITA 0m */
         { var m=peekb(nxtpcb()); and8(A(),m); ticks+=2; break; }
         case 150:   /* LDAA 0m */
         { var m=peekb(nxtpcb()); setA(ld8(m)); ticks+=2; break; }
         case 151:   /* STAA 0m */
         { var m=nxtpcb(); pokeb(m,ld8(A())); ticks+=2; break; }
         case 152:   /* EORA 0m */
         { var m=peekb(nxtpcb()); setA(eor8(A(),m)); ticks+=2; break; }
         case 153:   /* ADCA 0m */
         { var m=peekb(nxtpcb()); setA(adc8(A(),m)); ticks+=2; break; }
         case 154:   /* ORAA 0m */
         { var m=peekb(nxtpcb()); setA(or8(A(),m)); ticks+=2; break; }
         case 155:   /* ADDA 0m */
         { var m=peekb(nxtpcb()); setA(add8(A(),m)); ticks+=2; break; }
         case 156:   /* CPX 0m */
         { var m=peekw(nxtpcb()); sub16(X(),m); ticks+=3; break; }
         case 157:   /* JSR 0m */
         { var m=nxtpcb(); pushw(PC()); setPC(m); ticks+=4; break; }
         case 158:   /* LDS 0m */
         { var m=peekw(nxtpcb()); setSP(ld16(m)); ticks+=3; break; }
         case 159:   /* STS 0m */
         { var m=nxtpcb(); pokew(m,ld16(SP())); ticks+=3; break; }

         case 160:   /* SUBA d,X */
         { var m=peekb(X()+nxtpcb()); setA(sub8(A(),m)); ticks+=3; break; }
         case 161:   /* CMPA d,X */
         { var m=peekb(X()+nxtpcb()); sub8(A(),m); ticks+=3; break; }
         case 162:   /* SBCA d,X */
         { var m=peekb(X()+nxtpcb()); setA(sbc8(A(),m)); ticks+=3; break; }
         case 163:   /* SUBD d,X */
         { var m=peekw(X()+nxtpcb()); setD(sub16(D(),m)); ticks+=4; break; }
         case 164:   /* ANDA d,X */
         { var m=peekb(X()+nxtpcb()); setA(and8(A(),m)); ticks+=3; break; }
         case 165:   /* BITA d,X */
         { var m=peekb(X()+nxtpcb()); and8(A(),m); ticks+=3; break; }
         case 166:   /* LDAA d,X */
         { var m=peekb(X()+nxtpcb()); setA(ld8(m)); ticks+=3; break; }
         case 167:   /* STAA d,X */
         { var m=X()+nxtpcb(); pokeb(m,ld8(A())); ticks+=3; break; }
         case 168:   /* EORA d,X */
         { var m=peekb(X()+nxtpcb()); setA(eor8(A(),m)); ticks+=3; break; }
         case 169:   /* ADCA d,X */
         { var m=peekb(X()+nxtpcb()); setA(adc8(A(),m)); ticks+=3; break; }
         case 170:   /* ORAA d,X */
         { var m=peekb(X()+nxtpcb()); setA(or8(A(),m)); ticks+=3; break; }
         case 171:   /* ADDA d,X */
         { var m=peekb(X()+nxtpcb()); setA(add8(A(),m)); ticks+=3; break; }
         case 172:   /* CPX d,X */
         { var m=peekw(X()+nxtpcb()); sub16(X(),m); ticks+=4; break; }
         case 173:   /* JSR d,X */
         { var m=X()+nxtpcb(); pushw(PC()); setPC(m); ticks+=4; break; }
         case 174:   /* LDS d,X */
         { var m=peekw(X()+nxtpcb()); setSP(ld16(m)); ticks+=4; break; }
         case 175:   /* STS d,X */
         { var m=X()+nxtpcb(); pokew(m,ld16(SP())); ticks+=4; break; }

         case 176:   /* SUBA mm */
         { var m=peekb(nxtpcw()); setA(sub8(A(),m)); ticks+=3; break; }
         case 177:   /* CMPA mm */
         { var m=peekb(nxtpcw()); sub8(A(),m); ticks+=3; break; }
         case 178:   /* SBCA mm */
         { var m=peekb(nxtpcw()); setA(sbc8(A(),m)); ticks+=3; break; }
         case 179:   /* SUBD mm */
         { var m=peekw(nxtpcw()); setD(sub16(D(),m)); ticks+=4; break; }
         case 180:   /* ANDA mm */
         { var m=peekb(nxtpcw()); setA(and8(A(),m)); ticks+=3; break; }
         case 181:   /* BITA mm */
         { var m=peekb(nxtpcw()); and8(A(),m); ticks+=3; break; }
         case 182:   /* LDAA mm */
         { var m=peekb(nxtpcw()); setA(ld8(m)); ticks+=3; break; }
         case 183:   /* STAA mm */
         { var m=nxtpcw(); pokeb(m,ld8(A())); ticks+=3; break; }
         case 184:   /* EORA mm */
         { var m=peekb(nxtpcw()); setA(eor8(A(),m)); ticks+=3; break; }
         case 185:   /* ADCA mm */
         { var m=peekb(nxtpcw()); setA(adc8(A(),m)); ticks+=3; break; }
         case 186:   /* ORAA mm */
         { var m=peekb(nxtpcw()); setA(or8(A(),m)); ticks+=3; break; }
         case 187:   /* ADDA mm */
         { var m=peekb(nxtpcw()); setA(add8(A(),m)); ticks+=3; break; }
         case 188:   /* CPX mm */
         { var m=peekw(nxtpcw()); sub16(X(),m); ticks+=4; break; }
         case 189:   /* JSR mm */
         { var m=nxtpcw(); pushw(PC()); setPC(m); ticks+=5; break; }
         case 190:   /* LDS mm */
         { var m=peekw(nxtpcw()); setSP(ld16(m)); ticks+=4; break; }
         case 191:   /* STS mm */
         { var m=nxtpcw(); pokew(m,ld16(SP())); ticks+=4; break; }


         case 192:   /* SUBB # */
         { var m=nxtpcb(); setB(sub8(B(),m)); ticks++; break; }
         case 193:   /* CMPB # */
         { var m=nxtpcb(); sub8(B(),m); ticks++; break; }
         case 194:   /* SBCB # */
         { var m=nxtpcb(); setB(sbc8(B(),m)); ticks++; break; }
         case 195:   /* ADDD ## */
         { var m=nxtpcw(); setD(add16(D(),m)); ticks+=2; break; }
         case 196:   /* ANDB # */
         { var m=nxtpcb(); setB(and8(B(),m)); ticks++; break; }
         case 197:   /* BITB # */
         { var m=nxtpcb(); and8(B(),m); ticks++; break; }
         case 198:   /* LDAB # */
         { var m=nxtpcb(); setB(ld8(m)); ticks++; break; }
         case 200:   /* EORB # */
         { var m=nxtpcb(); setB(eor8(B(),m)); ticks++; break; }
         case 201:   /* ADCB # */
         { var m=nxtpcb(); setB(adc8(B(),m)); ticks++; break; }
         case 202:   /* ORAB # */
         { var m=nxtpcb(); setB(or8(B(),m)); ticks++; break; }
         case 203:   /* ADDB # */
         { var m=nxtpcb(); setB(add8(B(),m)); ticks++; break; }
         case 204:   /* LDD ## */
         { var m=nxtpcw(); setD(ld16(m)); ticks+=2; break; }
         case 206:   /* LDX ## */
         { var m=nxtpcw(); setX(ld16(m)); ticks+=2; break; }

         case 208:   /* SUBB 0m */
         { var m=peekb(nxtpcb()); setB(sub8(B(),m)); ticks+=2; break; }
         case 209:   /* CMPB 0m */
         { var m=peekb(nxtpcb()); sub8(B(),m); ticks+=2; break; }
         case 210:   /* SBCB 0m */
         { var m=peekb(nxtpcb()); setB(sbc8(B(),m)); ticks+=2; break; }
         case 211:   /* ADDD 0m */
         { var m=peekw(nxtpcb()); setD(add16(D(),m)); ticks+=3; break; }
         case 212:   /* ANDB 0m */
         { var m=peekb(nxtpcb()); setB(and8(B(),m)); ticks+=2; break; }
         case 213:   /* BITB 0m */
         { var m=peekb(nxtpcb()); and8(B(),m); ticks+=2; break; }
         case 214:   /* LDAB 0m */
         { var m=peekb(nxtpcb()); setB(ld8(m)); ticks+=2; break; }
         case 215:   /* STAB 0m */
         { var m=nxtpcb(); pokeb(m,ld8(B())); ticks+=2; break; }
         case 216:   /* EORB 0m */
         { var m=peekb(nxtpcb()); setB(eor8(B(),m)); ticks+=2; break; }
         case 217:   /* ADCB 0m */
         { var m=peekb(nxtpcb()); setB(adc8(B(),m)); ticks+=2; break; }
         case 218:   /* ORAB 0m */
         { var m=peekb(nxtpcb()); setB(or8(B(),m)); ticks+=2; break; }
         case 219:   /* ADDB 0m */
         { var m=peekb(nxtpcb()); setB(add8(B(),m)); ticks+=2; break; }
         case 220:   /* LDD 0m */
         { var m=peekw(nxtpcb()); setD(ld16(m)); ticks+=3; break; }
         case 221:   /* STD 0m */
         { var m=nxtpcb(); pokew(m,ld16(D())); ticks+=3; break; }
         case 222:   /* LDX 0m */
         { var m=peekw(nxtpcb()); setX(ld16(m)); ticks+=3; break; }
         case 223:   /* STX 0m */
         { var m=nxtpcb(); pokew(m,ld16(X())); ticks+=3; break; }

         case 224:   /* SUBB d,X */
         { var m=peekb(X()+nxtpcb()); setB(sub8(B(),m)); ticks+=3; break; }
         case 225:   /* CMPB d,X */
         { var m=peekb(X()+nxtpcb()); sub8(B(),m); ticks+=3; break; }
         case 226:   /* SBCB d,X */
         { var m=peekb(X()+nxtpcb()); setB(sbc8(B(),m)); ticks+=3; break; }
         case 227:   /* ADDD d,X */
         { var m=peekw(X()+nxtpcb()); setD(add16(D(),m)); ticks+=4; break; }
         case 228:   /* ANDB d,X */
         { var m=peekb(X()+nxtpcb()); setB(and8(B(),m)); ticks+=3; break; }
         case 229:   /* BITB d,X */
         { var m=peekb(X()+nxtpcb()); and8(B(),m); ticks+=3; break; }
         case 230:   /* LDAB d,X */
         { var m=peekb(X()+nxtpcb()); setB(ld8(m)); ticks+=3; break; }
         case 231:   /* STAB d,X */
         { var m=X()+nxtpcb(); pokeb(m,ld8(B())); ticks+=3; break; }
         case 232:   /* EORB d,X */
         { var m=peekb(X()+nxtpcb()); setB(eor8(B(),m)); ticks+=3; break; }
         case 233:   /* ADCB d,X */
         { var m=peekb(X()+nxtpcb()); setB(adc8(B(),m)); ticks+=3; break; }
         case 234:   /* ORAB d,X */
         { var m=peekb(X()+nxtpcb()); setB(or8(B(),m)); ticks+=3; break; }
         case 235:   /* ADDB d,X */
         { var m=peekb(X()+nxtpcb()); setB(add8(B(),m)); ticks+=3; break; }
         case 236:   /* LDD d,X */
         { var m=peekw(X()+nxtpcb()); setD(ld16(m)); ticks+=4; break; }
         case 237:   /* STD d,X */
         { var m=X()+nxtpcb(); pokew(m,ld16(D())); ticks+=4; break; }
         case 238:   /* LDX d,X */
         { var m=peekw(X()+nxtpcb()); setX(ld16(m)); ticks+=4; break; }
         case 239:   /* STX d,X */
         { var m=X()+nxtpcb(); pokew(m,ld16(X())); ticks+=4; break; }

         case 240:   /* SUBB mm */
         { var m=peekb(nxtpcw()); setB(sub8(B(),m)); ticks+=3; break; }
         case 241:   /* CMPB mm */
         { var m=peekb(nxtpcw()); sub8(B(),m); ticks+=3; break; }
         case 242:   /* SBCB mm */
         { var m=peekb(nxtpcw()); setB(sbc8(B(),m)); ticks+=3; break; }
         case 243:   /* ADDD mm */
         { var m=peekw(nxtpcw()); setD(add16(D(),m)); ticks+=4; break; }
         case 244:   /* ANDB mm */
         { var m=peekb(nxtpcw()); setB(and8(B(),m)); ticks+=3; break; }
         case 245:   /* BITB mm */
         { var m=peekb(nxtpcw()); and8(B(),m); ticks+=3; break; }
         case 246:   /* LDAB mm */
         { var m=peekb(nxtpcw()); setB(ld8(m)); ticks+=3; break; }
         case 247:   /* STAB mm */
         { var m=nxtpcw(); pokeb(m,ld8(B())); ticks+=3; break; }
         case 248:   /* EORB mm */
         { var m=peekb(nxtpcw()); setB(eor8(B(),m)); ticks+=3; break; }
         case 249:   /* ADCB mm */
         { var m=peekb(nxtpcw()); setB(adc8(B(),m)); ticks+=3; break; }
         case 250:   /* ORAB mm */
         { var m=peekb(nxtpcw()); setB(or8(B(),m)); ticks+=3; break; }
         case 251:   /* ADDB mm */
         { var m=peekb(nxtpcw()); setB(add8(B(),m)); ticks+=3; break; }
         case 252:   /* LDD mm */
         { var m=peekw(nxtpcw()); setD(ld16(m)); ticks+=4; break; }
         case 253:   /* STD mm */
         { var m=nxtpcw(); pokew(m,ld16(D())); ticks+=4; break; }
         case 254:   /* LDX mm */
         { var m=peekw(nxtpcw()); setX(ld16(m)); ticks+=4; break; }
         case 255:   /* STX mm */
         { var m=nxtpcw(); pokew(m,ld16(X())); ticks+=4; break; }
         default:
         {
            console.log("error!  instr="+inst+"  PC="+PC());
            _bus.switchOff();
            break;
         }
         }

         // adjust interrupt counters
         _bus.incFrame(ticks);

         ticksToExecute -= ticks;

      } // end while
   }


   /** set NZV flags for LD command */
   function ld8( a )
   {
      setN( (a & 0x80 ) != 0 );
      setZ(  a == 0 );
      setV( false );
      return a;
   }
   function ld16( a )
   {
      setN( (a & 0x8000 ) != 0 );
      setZ(  a == 0 );
      setV( false );
      return a;
   }
   /** Decimal Adjust Accumulator */
   function daa()
   {
      var ans = A();
      if( Hset() ) ans+=0x06;
      if ( ((ans & 0x0f) > 0x09)) ans += 0x06;
      if( Cset() ) ans+=0x60;
      if ( ans > 0x9f ) ans += 0x60;
      if ( ans > 0x99 ) setC(true);

      setN( (ans & 0x80 ) != 0 );
      setZ( (ans & 0xff ) == 0 );
      // if a,b same sign, and answer is different sign then overflow
      setV( ((A() ^ ans) & 0x80) != 0 );
      setA(ans&0xff);
   }


   /** Negate - alters NZCV */
   function neg8( ans )
   {
      var ans2 = (-ans)&0xff;
      setN( (ans2 & 0x80)!=0 );
      setZ( ans2 == 0 );
      setC( ans2 != 0 );
      setV( ans2 == 0x80 );
      return ans2;
   }
   /** Complement - alters NZCV */
   function com8( ans )
   {
      var ans2 = ans^0xff;
      setN( (ans2 & 0x80)!=0 );
      setZ( ans2 == 0 );
      setV( false );
      setC( true );
      return ans2;
   }
   /** Logical Shift Right - alters NZCV */
   function lsr( ans )
   {
      var c = (ans&1)!=0;
      setC( c );
      setV( c );
      var ans2 = ans>>1;
      setN( false );
      setZ( ans2==0 );
      return ans2;
   }
   /** Rotate Right - alters NZCV */
   function ror8( ans )
   {
      var c = (ans&1)!=0;
      var n = Cset();
      var ans2 = ans>>1;
      if(n){
         ans2|=0x80;
      }
      setC( c );
      setN( n );
      setZ( ans2==0 );
      setV( n!=c );
      return ans2;
   }
   /** Arithmetical Shift Right - alters NZCV */
   function asr8( ans )
   {
      var c=(ans&1)!=0;
      var msb=ans&0x80;
      var n= msb!=0;
      setC( c );
      var ans2=(ans>>1)+msb;
      setN( n );
      setZ( ans2==0 );
      setV( n!=c );
      return ans2;
   }
   /** Arithmetical Shift Left - alters NZCV */
   function asl8( ans )
   {
      var c = (ans & 0x80) != 0;
      var ans2 = (ans << 1) & 0xff;
      var n = (ans2 & 0x80) != 0;
      setN( n );
      setZ( ans2 == 0 );
      setC( c );
      setV( n != c );
      return ans2;
   }
   /** Rotate Left - alters NZCV */
   function rol8( ans )
   {
      var c = (ans&0x80)!=0;
      var ans2=(ans<<1)&0xff;
      var n = (ans2&0x80)!=0;
      if(Cset()) ans2++;
      setC( c );
      setN( n );
      setZ( ans2==0 );
      setV( n!=c );
      return ans2;
   }
   /** Decrease - alters NZV */
   function dec8( ans )
   {
      setV( ans==0x80 );
      var ans2=(ans-1)&0xff;
      setN( (ans2&0x80)!=0 );
      setZ( ans2==0 );
      return ans2;
   }
   /** Increase - alters NZV */
   function inc8( ans )
   {
      var ans2=(ans+1)&0xff;
      setV( ans2==0x80 );
      setN( (ans2&0x80)!=0 );
      setZ( ans2==0 );
      return ans2;
   }
   /** Test - alters NZVC */
   function tst8( ans )
   {
      setV( false );
      setC( false );
      setN( (ans&0x80)!=0 );
      setZ( ans==0 );
   }
   /** Clear - alters NZVC */
   function clr8()
   {
      setV( false );
      setC( false );
      setN( false );
      setZ( true );
      return(0);
   }

   /** And - alters NZV */
   function and8( a, b )
   {
      var ans=a&b;
      setV( false );
      setN( (ans&0x80)!=0 );
      setZ( ans==0 );
      return(ans);
   }
   /** or - alters NZV */
   function or8( a, b )
   {
      var ans=a|b;
      setV( false );
      setN( (ans&0x80)!=0 );
      setZ( ans==0 );
      return(ans);
   }
   /** eor - alters NZV */
   function eor8( a, b )
   {
      var ans=a^b;
      setV( false );
      setN( (ans&0x80)!=0 );
      setZ( ans==0 );
      return(ans);
   }

   /** Add - alters HNZCV */
   function add8( a, b )
   {
      var ans = a + b;
      setH( ((a & 0x0f) + (b & 0x0f)) >= 0x10 );
      setN( (ans & 0x80 ) != 0 );
      setZ( (ans & 0xff ) == 0 );
      setC( (ans & 0x100) != 0 );
      // if a,b same sign, and answer is different sign then overflow
      setV( ((a ^ ~b) & (a ^ ans) & 0x80) != 0 );
      return( ans & 0xff );
   }

   /** Add with carry - alters HNZCV */
   function adc8( a, b )
   {
      var c = Cset()?1:0;
      var ans = a + b + c;
      setH( ((a & 0x0f) + (b & 0x0f) + c) >= 0x10 );
      setN( (ans & 0x80 ) != 0 );
      setZ( (ans & 0xff ) == 0 );
      setC( (ans & 0x100) != 0 );
      // if a,b same sign, and answer is different sign then overflow
      setV( ((a ^ ~b) & (a ^ ans) & 0x80) != 0 );
      return ans & 0xff;
   }
   /** Subtract - alters NZCV */
   function sub8( a, b )
   {
      var ans = a - b;
      setN( (ans & 0x80 ) != 0 );
      setZ( (ans & 0xff ) == 0 );
      setC( (ans & 0x100) != 0 );
      // if a,b different sign, and answer is different sign then overflow
      setV( ((a ^ b) & (a ^ ans) & 0x80) != 0 );
      return( ans & 0xff );
   }
   /** Subtract with carry - alters NZCV */
   function sbc8( a, b )
   {
      var b2 = b;
      if( Cset() ) b2++;
      var ans = a - b2;
      setN( (ans & 0x80 ) != 0 );
      setZ( (ans & 0xff ) == 0 );
      setC( (ans & 0x100) != 0 );
      // if a,b different sign, and answer is different sign then overflow
      setV( ((a ^ b2) & (a ^ ans) & 0x80) != 0 );
      return ans & 0xff;
   }
   /** Subtract - alters NZCV */
   function sub16( a, b )
   {
      var ans = a - b;
      setN( (ans & 0x8000 ) != 0 );
      setZ( (ans & 0xffff ) == 0 );
      setC( (ans & 0x10000) != 0 );
      // if a,b different sign, and answer is different sign then overflow
      setV( ((a ^ b) & (a ^ ans) & 0x8000) != 0 );
      return ans & 0xffff;
   }
   /** Add - alters NZCV */
   function add16( a, b )
   {
      var ans = a + b;
      setN( (ans & 0x8000 ) != 0 );
      setZ( (ans & 0xffff ) == 0 );
      setC( (ans & 0x10000) != 0 );
      // if a,b same sign, and answer is different sign then overflow
      setV( ((a ^ ~b) & (a ^ ans) & 0x8000) != 0 );
      return ans & 0xffff;
   }
   /** Shift Left Arithmetically - alters NZCV */
   function asl16( ans )
   {
      var c = (ans & 0x8000) != 0;
      var ans2 = (ans << 1) & 0xffff;
      var n = (ans2 & 0x8000) != 0;
      setN( n );
      setZ( ans2 == 0 );
      setC( c );
      setV( n != c );
      return ans2;
   }

   this.getSnapshotData = function(arr){
      var arr2 = [A(), B(), P(), X()>>8, X()&0xff, PC()>>8, PC()&0xff, SP()>>8, SP()&0xff, _sleep?1:0];
      var ln = arr.length;
      for( var i=0; i<arr2.length; i++) arr[ln++] = arr2[i];
      console.log( A()+", "+B()+", "+P()+", "+X()+", "+PC()+", "+SP()+", "+_sleep );
   }
   this.applySnapshotData = function(snapshot){
      setA(snapshot.readByte());
      setB(snapshot.readByte());
      setP(snapshot.readByte());
      setX(snapshot.readWord());
      setPC(snapshot.readWord());
      setSP(snapshot.readWord());
      _sleep = snapshot.readByte()!=0;
      console.log( A()+", "+B()+", "+P()+", "+X()+", "+PC()+", "+SP()+", "+_sleep );
   }
}
